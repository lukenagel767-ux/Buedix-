# BlueDesk Ultimate – GROK FINAL

Desktop-ähnliche Umgebung für **iPhone und iPad** mit Fenstern, Dock, Startmenü, Browser, Apps und interner Zeigersteuerung.

## Umgebungshinweis

Dieses Paket wurde auf **Linux ohne Xcode** erstellt und überarbeitet.  
Es wurde **kein** Xcode-Build und **kein** Geräte-/Simulator-Test ausgeführt.

## Voraussetzungen (Intel-MacBook Pro)

- macOS + **Xcode 14 oder neuer** (15/16 empfohlen)
- Deployment Target: **iOS 16.0 / iPadOS 16.0**
- Apple-ID für Signing (Free Provisioning reicht für Simulator und eigenes Gerät)

## Öffnen und Bauen

1. `BlueDeskUltimate_GROK_FINAL.zip` entpacken  
2. `BlueDeskUltimate.xcodeproj` in Xcode öffnen  
3. Signing & Capabilities → **Team** wählen  
4. Bundle ID bei Bedarf anpassen (`com.bluedesk.ultimate`)  
5. Schema **BlueDeskUltimate** wählen, Gerät/Simulator  
6. **Product → Clean Build Folder**, dann **Build** (⌘B) und **Run** (⌘R)  
7. Tests: **Product → Test** (⌘U)

Falls Dateien rot markiert sind: Rechtsklick Projekt → *Add Files to "BlueDeskUltimate"* → Ordner `BlueDeskUltimate/` (ohne „Copy items“).

## Funktionen (Überblick)

- **Window Manager:** öffnen, schließen, Fokus, Min/Max, Verschieben, Skalieren, Snap-Layouts, virtuelle Arbeitsbereiche, Sitzungswiederherstellung  
- **Dock & Startmenü:** Anheften, aktive Apps, Suche  
- **Eingabe:** GCMouse/GCKeyboard; virtuelles Touchpad steuert internen Zeiger (Klick, Doppelklick, Ziehen); Touchpad wird **nur ausgeblendet, wenn Maus und Tastatur verbunden sind** und die Einstellung aktiv ist  
- **Browser:** WKWebView pro Tab, Zurück/Vor/Reload, Fehler, Lesezeichen  
- **YouTube / TikTok / Roblox:** offizielle Websites im Browser  
- **Dateien:** Document-Picker, Teilen, Mehrfachauswahl  
- **Notizen, Rechner, PDFKit, EventKit-Kalender, Medienplayer, Einstellungen**

## Grenzen

- Keine Einbettung fremder nativer Apps  
- Keine privaten APIs / kein Jailbreak  
- Interner Zeiger wirkt nur innerhalb der App  
- DRM/Login/WebRTC abhängig von Website und iOS  
- Externes Display: geräte- und systemabhängig  

## Tests

`BlueDeskUltimateTests`: WindowManager, InputDevice, Notes/Models.  
Auf dem Mac mit ⌘U ausführen – in der Erzeugungsumgebung nicht gelaufen.

Siehe `Docs/BUILD_REPORT.md`.
