import Foundation
import SwiftUI
import Combine

// MARK: - Window Model
struct DesktopWindow: Identifiable, Codable, Equatable {
    let id: UUID
    var title: String
    var appType: AppType
    var frame: CGRect
    var isMinimized: Bool
    var isMaximized: Bool
    var zIndex: Int
    var isFocused: Bool
    var contentURL: URL?
    var minSize: CGSize
    var workspaceID: UUID
    var savedFrameBeforeMaximize: CGRect?
    
    init(
        id: UUID = UUID(),
        title: String,
        appType: AppType,
        frame: CGRect = CGRect(x: 100, y: 100, width: 800, height: 600),
        isMinimized: Bool = false,
        isMaximized: Bool = false,
        zIndex: Int = 0,
        isFocused: Bool = false,
        contentURL: URL? = nil,
        minSize: CGSize = CGSize(width: 320, height: 240),
        workspaceID: UUID,
        savedFrameBeforeMaximize: CGRect? = nil
    ) {
        self.id = id
        self.title = title
        self.appType = appType
        self.frame = frame
        self.isMinimized = isMinimized
        self.isMaximized = isMaximized
        self.zIndex = zIndex
        self.isFocused = isFocused
        self.contentURL = contentURL
        self.minSize = minSize
        self.workspaceID = workspaceID
        self.savedFrameBeforeMaximize = savedFrameBeforeMaximize
    }
}

// MARK: - App Types
enum AppType: String, Codable, CaseIterable, Identifiable {
    case browser
    case youtube
    case tiktok
    case roblox
    case files
    case notes
    case calculator
    case settings
    case pdfViewer
    case mediaPlayer
    case calendar
    case downloads
    case webApp
    case about
    
    var id: String { rawValue }
    
    var displayName: String {
        switch self {
        case .browser: return "Browser"
        case .youtube: return "YouTube"
        case .tiktok: return "TikTok"
        case .roblox: return "Roblox"
        case .files: return "Dateien"
        case .notes: return "Notizen"
        case .calculator: return "Rechner"
        case .settings: return "Einstellungen"
        case .pdfViewer: return "PDF-Viewer"
        case .mediaPlayer: return "Medien"
        case .calendar: return "Kalender"
        case .downloads: return "Downloads"
        case .webApp: return "Web-App"
        case .about: return "Über BlueDesk"
        }
    }
    
    var systemImage: String {
        switch self {
        case .browser: return "globe"
        case .youtube: return "play.rectangle.fill"
        case .tiktok: return "music.note"
        case .roblox: return "gamecontroller.fill"
        case .files: return "folder.fill"
        case .notes: return "note.text"
        case .calculator: return "plus.forwardslash.minus"
        case .settings: return "gearshape.fill"
        case .pdfViewer: return "doc.richtext"
        case .mediaPlayer: return "play.circle.fill"
        case .calendar: return "calendar"
        case .downloads: return "arrow.down.circle.fill"
        case .webApp: return "app.badge"
        case .about: return "info.circle"
        }
    }
    
    var defaultURL: URL? {
        switch self {
        case .youtube: return URL(string: "https://www.youtube.com")
        case .tiktok: return URL(string: "https://www.tiktok.com")
        case .roblox: return URL(string: "https://www.roblox.com")
        case .browser: return URL(string: "https://www.apple.com")
        default: return nil
        }
    }
}

// MARK: - Virtual Workspace
struct VirtualWorkspace: Identifiable, Codable, Equatable {
    let id: UUID
    var name: String
    var icon: String
    var windowIDs: [UUID]
    
    init(id: UUID = UUID(), name: String, icon: String = "desktopcomputer", windowIDs: [UUID] = []) {
        self.id = id
        self.name = name
        self.icon = icon
        self.windowIDs = windowIDs
    }
}

// MARK: - Dock Item
struct DockItem: Identifiable, Codable, Equatable {
    let id: UUID
    var appType: AppType
    var isPinned: Bool
    var customURL: URL?
    var customTitle: String?
    var customIcon: String?
    
    init(
        id: UUID = UUID(),
        appType: AppType,
        isPinned: Bool = true,
        customURL: URL? = nil,
        customTitle: String? = nil,
        customIcon: String? = nil
    ) {
        self.id = id
        self.appType = appType
        self.isPinned = isPinned
        self.customURL = customURL
        self.customTitle = customTitle
        self.customIcon = customIcon
    }
    
    var displayTitle: String {
        customTitle ?? appType.displayName
    }
    
    var iconName: String {
        customIcon ?? appType.systemImage
    }
}

// MARK: - Bookmark
struct Bookmark: Identifiable, Codable, Equatable {
    let id: UUID
    var title: String
    var url: URL
    var faviconData: Data?
    var createdAt: Date
    var folder: String?
    
    init(id: UUID = UUID(), title: String, url: URL, faviconData: Data? = nil, createdAt: Date = Date(), folder: String? = nil) {
        self.id = id
        self.title = title
        self.url = url
        self.faviconData = faviconData
        self.createdAt = createdAt
        self.folder = folder
    }
}

// MARK: - Note
struct Note: Identifiable, Codable, Equatable {
    let id: UUID
    var title: String
    var content: String
    var createdAt: Date
    var modifiedAt: Date
    var isMarkdown: Bool
    
    init(id: UUID = UUID(), title: String = "Neue Notiz", content: String = "", createdAt: Date = Date(), modifiedAt: Date = Date(), isMarkdown: Bool = false) {
        self.id = id
        self.title = title
        self.content = content
        self.createdAt = createdAt
        self.modifiedAt = modifiedAt
        self.isMarkdown = isMarkdown
    }
}

// MARK: - Download Item
struct DownloadItem: Identifiable, Codable, Equatable {
    let id: UUID
    var filename: String
    var sourceURL: URL
    var localURL: URL?
    var progress: Double
    var state: DownloadState
    var totalBytes: Int64?
    var receivedBytes: Int64
    var startedAt: Date
    var finishedAt: Date?
    
    enum DownloadState: String, Codable {
        case pending, downloading, completed, failed, cancelled
    }
    
    init(
        id: UUID = UUID(),
        filename: String,
        sourceURL: URL,
        localURL: URL? = nil,
        progress: Double = 0,
        state: DownloadState = .pending,
        totalBytes: Int64? = nil,
        receivedBytes: Int64 = 0,
        startedAt: Date = Date(),
        finishedAt: Date? = nil
    ) {
        self.id = id
        self.filename = filename
        self.sourceURL = sourceURL
        self.localURL = localURL
        self.progress = progress
        self.state = state
        self.totalBytes = totalBytes
        self.receivedBytes = receivedBytes
        self.startedAt = startedAt
        self.finishedAt = finishedAt
    }
}

// MARK: - App Settings
struct AppSettings: Codable, Equatable {
    var accentColor: String = "007AFF" // Blue
    var isDarkMode: Bool = true
    var wallpaperName: String = "defaultDark"
    var dockSize: Double = 64
    var iconSize: Double = 48
    var transparencyEnabled: Bool = true
    var reduceMotion: Bool = false
    var showVirtualTouchpad: Bool = true
    var preferExternalInput: Bool = true
    var defaultSearchEngine: String = "https://www.google.com/search?q="
    var restoreSession: Bool = true
    var language: String = "de"
    
    static let defaultSettings = AppSettings()
}

// MARK: - Snap Layout
enum SnapLayout: String, CaseIterable {
    case leftHalf
    case rightHalf
    case topHalf
    case bottomHalf
    case topLeft
    case topRight
    case bottomLeft
    case bottomRight
    case fullScreen
    case center
}