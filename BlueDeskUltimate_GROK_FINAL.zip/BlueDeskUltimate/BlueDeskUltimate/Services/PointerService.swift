import Foundation
import SwiftUI
import Combine

/// Internal desktop pointer managed by BlueDesk (app-scoped only).
/// Driven by the virtual touchpad. Does not control the system cursor.
@MainActor
final class PointerService: ObservableObject {
    
    static let shared = PointerService()
    
    @Published var position: CGPoint = CGPoint(x: 200, y: 200)
    @Published var isVisible: Bool = true
    @Published var isPressed: Bool = false
    @Published var isDraggingWindow: Bool = false
    
    /// Window currently being dragged by the pointer (title-bar drag)
    @Published var draggingWindowID: UUID?
    
    var screenBounds: CGRect = CGRect(x: 0, y: 0, width: 1024, height: 768)
    
    private var lastClickTime: Date = .distantPast
    private var lastClickPosition: CGPoint = .zero
    private let doubleClickInterval: TimeInterval = 0.35
    private let doubleClickDistance: CGFloat = 12
    
    private init() {}
    
    // MARK: - Movement
    
    func move(by delta: CGSize) {
        var newPos = position
        newPos.x += delta.width
        newPos.y += delta.height
        newPos.x = max(0, min(screenBounds.width, newPos.x))
        newPos.y = max(0, min(screenBounds.height, newPos.y))
        
        // If dragging a window, move its frame
        if isDraggingWindow, let id = draggingWindowID {
            NotificationCenter.default.post(
                name: .blueDeskPointerDragWindow,
                object: nil,
                userInfo: ["id": id, "delta": delta]
            )
        }
        
        position = newPos
        isVisible = true
    }
    
    func move(to point: CGPoint) {
        var newPos = point
        newPos.x = max(0, min(screenBounds.width, newPos.x))
        newPos.y = max(0, min(screenBounds.height, newPos.y))
        position = newPos
        isVisible = true
    }
    
    // MARK: - Press / Release / Click
    
    func press() {
        isPressed = true
    }
    
    func release() {
        isPressed = false
        if isDraggingWindow {
            isDraggingWindow = false
            draggingWindowID = nil
        }
    }
    
    /// Single click. Returns true if it was interpreted as a double-click.
    @discardableResult
    func click() -> Bool {
        let now = Date()
        let dist = hypot(position.x - lastClickPosition.x, position.y - lastClickPosition.y)
        let isDouble = now.timeIntervalSince(lastClickTime) < doubleClickInterval && dist < doubleClickDistance
        
        press()
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.08) { [weak self] in
            self?.release()
        }
        
        lastClickTime = now
        lastClickPosition = position
        return isDouble
    }
    
    func startWindowDrag(windowID: UUID) {
        isDraggingWindow = true
        draggingWindowID = windowID
        isPressed = true
    }
    
    func endWindowDrag() {
        isDraggingWindow = false
        draggingWindowID = nil
        isPressed = false
    }
    
    // MARK: - Hit testing
    
    func windowUnderPointer(in windows: [DesktopWindow]) -> DesktopWindow? {
        windows
            .filter { !$0.isMinimized }
            .filter { $0.frame.contains(position) }
            .sorted { $0.zIndex > $1.zIndex }
            .first
    }
    
    /// True if pointer is over the title-bar region of the window (top ~36 pt).
    func isOverTitleBar(of window: DesktopWindow) -> Bool {
        let titleBar = CGRect(x: window.frame.minX, y: window.frame.minY, width: window.frame.width, height: 36)
        return titleBar.contains(position)
    }
}

extension Notification.Name {
    static let blueDeskPointerDragWindow = Notification.Name("BlueDesk.PointerDragWindow")
    static let blueDeskPointerClick = Notification.Name("BlueDesk.PointerClick")
}
