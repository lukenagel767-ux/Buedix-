import Foundation
import Combine
import GameController
#if canImport(UIKit)
import UIKit
#endif

/// Detects external mouse and keyboard and prioritizes them over the virtual touchpad.
/// When both mouse and keyboard are connected, the on-screen touchpad is hidden.
@MainActor
final class InputDeviceService: ObservableObject {
    
    static let shared = InputDeviceService()
    
    @Published private(set) var isMouseConnected: Bool = false
    @Published private(set) var isKeyboardConnected: Bool = false
    @Published private(set) var shouldShowVirtualTouchpad: Bool = true
    @Published private(set) var connectedMice: [String] = []
    @Published private(set) var connectedKeyboards: [String] = []
    
    private var cancellables = Set<AnyCancellable>()
    private var preferExternalInput: Bool = true
    
    private init() {
        setupObservers()
        refreshDeviceStatus()
    }
    
    func updatePreferExternalInput(_ prefer: Bool) {
        preferExternalInput = prefer
        updateTouchpadVisibility()
    }
    
    // MARK: - Public API
    
    /// Call this periodically or on scene phase changes.
    func refreshDeviceStatus() {
        var mice: [String] = []
        var keyboards: [String] = []
        
        // GameController mice (Bluetooth / USB)
        for mouse in GCMouse.mice() {
            if let name = mouse.vendorName ?? mouse.productCategory {
                mice.append(name)
            } else {
                mice.append("External Mouse")
            }
        }
        
        // GameController keyboards
        for keyboard in GCKeyboard.coalesced.map({ [$0] }) ?? [] {
            if let name = keyboard.vendorName ?? keyboard.productCategory {
                keyboards.append(name)
            } else {
                keyboards.append("External Keyboard")
            }
        }
        
        // Also check GCController for controllers that may expose pointer
        for controller in GCController.controllers() {
            if controller.extendedGamepad != nil || controller.microGamepad != nil {
                // Controllers are handled separately; we focus on mouse/keyboard
            }
        }
        
        #if canImport(UIKit)
        // Additional check via UIDevice / trait collection is limited;
        // GCMouse / GCKeyboard are the primary public APIs for this.
        #endif
        
        let mouseConnected = !mice.isEmpty
        let keyboardConnected = !keyboards.isEmpty
        
        isMouseConnected = mouseConnected
        isKeyboardConnected = keyboardConnected
        connectedMice = mice
        connectedKeyboards = keyboards
        
        updateTouchpadVisibility()
    }
    
    private func updateTouchpadVisibility() {
        // Hide virtual touchpad only when BOTH mouse AND keyboard are connected
        // AND the user prefers external input. Mouse alone keeps the touchpad visible
        // as a fallback (per product requirement).
        if preferExternalInput && isMouseConnected && isKeyboardConnected {
            shouldShowVirtualTouchpad = false
        } else {
            shouldShowVirtualTouchpad = true
        }
    }
    
    private func setupObservers() {
        NotificationCenter.default.publisher(for: .GCMouseDidConnect)
            .receive(on: DispatchQueue.main)
            .sink { [weak self] _ in
                self?.refreshDeviceStatus()
            }
            .store(in: &cancellables)
        
        NotificationCenter.default.publisher(for: .GCMouseDidDisconnect)
            .receive(on: DispatchQueue.main)
            .sink { [weak self] _ in
                self?.refreshDeviceStatus()
            }
            .store(in: &cancellables)
        
        NotificationCenter.default.publisher(for: .GCKeyboardDidConnect)
            .receive(on: DispatchQueue.main)
            .sink { [weak self] _ in
                self?.refreshDeviceStatus()
            }
            .store(in: &cancellables)
        
        NotificationCenter.default.publisher(for: .GCKeyboardDidDisconnect)
            .receive(on: DispatchQueue.main)
            .sink { [weak self] _ in
                self?.refreshDeviceStatus()
            }
            .store(in: &cancellables)
        
        // Also observe controller connect/disconnect as some devices appear there
        NotificationCenter.default.publisher(for: .GCControllerDidConnect)
            .receive(on: DispatchQueue.main)
            .sink { [weak self] _ in
                self?.refreshDeviceStatus()
            }
            .store(in: &cancellables)
        
        NotificationCenter.default.publisher(for: .GCControllerDidDisconnect)
            .receive(on: DispatchQueue.main)
            .sink { [weak self] _ in
                self?.refreshDeviceStatus()
            }
            .store(in: &cancellables)
    }
    
    /// Status string for diagnostics
    var statusDescription: String {
        var parts: [String] = []
        if isMouseConnected {
            parts.append("Maus: \(connectedMice.joined(separator: ", "))")
        } else {
            parts.append("Maus: nicht verbunden")
        }
        if isKeyboardConnected {
            parts.append("Tastatur: \(connectedKeyboards.joined(separator: ", "))")
        } else {
            parts.append("Tastatur: nicht verbunden")
        }
        parts.append(shouldShowVirtualTouchpad ? "Virtuelles Touchpad: aktiv" : "Virtuelles Touchpad: ausgeblendet")
        return parts.joined(separator: " | ")
    }
}