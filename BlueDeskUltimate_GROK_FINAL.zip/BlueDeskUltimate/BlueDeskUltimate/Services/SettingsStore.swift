import Foundation
import SwiftUI
import Combine

@MainActor
final class SettingsStore: ObservableObject {
    
    static let shared = SettingsStore()
    
    @Published var settings: AppSettings {
        didSet { save() }
    }
    
    @Published var bookmarks: [Bookmark] = []
    @Published var notes: [Note] = []
    @Published var dockItems: [DockItem] = []
    @Published var downloads: [DownloadItem] = []
    
    private let settingsKey = "BlueDesk.Settings"
    private let bookmarksKey = "BlueDesk.Bookmarks"
    private let notesKey = "BlueDesk.Notes"
    private let dockKey = "BlueDesk.Dock"
    private let downloadsKey = "BlueDesk.Downloads"
    
    private init() {
        if let data = UserDefaults.standard.data(forKey: settingsKey),
           let decoded = try? JSONDecoder().decode(AppSettings.self, from: data) {
            settings = decoded
        } else {
            settings = .defaultSettings
        }
        
        loadBookmarks()
        loadNotes()
        loadDock()
        loadDownloads()
        
        // Seed default dock if empty
        if dockItems.isEmpty {
            dockItems = [
                DockItem(appType: .browser),
                DockItem(appType: .youtube),
                DockItem(appType: .tiktok),
                DockItem(appType: .roblox),
                DockItem(appType: .files),
                DockItem(appType: .notes),
                DockItem(appType: .calculator),
                DockItem(appType: .downloads),
                DockItem(appType: .settings)
            ]
            saveDock()
        }
    }
    
    // MARK: - Settings
    
    private func save() {
        if let data = try? JSONEncoder().encode(settings) {
            UserDefaults.standard.set(data, forKey: settingsKey)
        }
        UserDefaults.standard.set(settings.restoreSession, forKey: "BlueDesk.Settings.restoreSession")
        // Propagate input preference
        InputDeviceService.shared.updatePreferExternalInput(settings.preferExternalInput)
    }
    
    var accentColor: Color {
        Color(hex: settings.accentColor) ?? .blue
    }
    
    // MARK: - Bookmarks
    
    func addBookmark(title: String, url: URL) {
        let bm = Bookmark(title: title, url: url)
        bookmarks.insert(bm, at: 0)
        saveBookmarks()
    }
    
    func removeBookmark(_ id: UUID) {
        bookmarks.removeAll { $0.id == id }
        saveBookmarks()
    }
    
    private func saveBookmarks() {
        if let data = try? JSONEncoder().encode(bookmarks) {
            UserDefaults.standard.set(data, forKey: bookmarksKey)
        }
    }
    
    private func loadBookmarks() {
        if let data = UserDefaults.standard.data(forKey: bookmarksKey),
           let decoded = try? JSONDecoder().decode([Bookmark].self, from: data) {
            bookmarks = decoded
        }
    }
    
    // MARK: - Notes
    
    func addNote(_ note: Note = Note()) {
        notes.insert(note, at: 0)
        saveNotes()
    }
    
    func updateNote(_ note: Note) {
        if let idx = notes.firstIndex(where: { $0.id == note.id }) {
            var updated = note
            updated.modifiedAt = Date()
            notes[idx] = updated
            saveNotes()
        }
    }
    
    func deleteNote(_ id: UUID) {
        notes.removeAll { $0.id == id }
        saveNotes()
    }
    
    private func saveNotes() {
        if let data = try? JSONEncoder().encode(notes) {
            UserDefaults.standard.set(data, forKey: notesKey)
        }
    }
    
    private func loadNotes() {
        if let data = UserDefaults.standard.data(forKey: notesKey),
           let decoded = try? JSONDecoder().decode([Note].self, from: data) {
            notes = decoded
        }
    }
    
    // MARK: - Dock
    
    func pinToDock(_ item: DockItem) {
        if !dockItems.contains(where: { $0.appType == item.appType && $0.customURL == item.customURL }) {
            dockItems.append(item)
            saveDock()
        }
    }
    
    func unpinFromDock(_ id: UUID) {
        dockItems.removeAll { $0.id == id }
        saveDock()
    }
    
    func reorderDock(from source: IndexSet, to destination: Int) {
        dockItems.move(fromOffsets: source, toOffset: destination)
        saveDock()
    }
    
    private func saveDock() {
        if let data = try? JSONEncoder().encode(dockItems) {
            UserDefaults.standard.set(data, forKey: dockKey)
        }
    }
    
    private func loadDock() {
        if let data = UserDefaults.standard.data(forKey: dockKey),
           let decoded = try? JSONDecoder().decode([DockItem].self, from: data) {
            dockItems = decoded
        }
    }
    
    // MARK: - Downloads
    
    func addDownload(_ item: DownloadItem) {
        downloads.insert(item, at: 0)
        saveDownloads()
    }
    
    func updateDownload(_ item: DownloadItem) {
        if let idx = downloads.firstIndex(where: { $0.id == item.id }) {
            downloads[idx] = item
            saveDownloads()
        }
    }
    
    func removeDownload(_ id: UUID) {
        downloads.removeAll { $0.id == id }
        saveDownloads()
    }
    
    private func saveDownloads() {
        if let data = try? JSONEncoder().encode(downloads) {
            UserDefaults.standard.set(data, forKey: downloadsKey)
        }
    }
    
    private func loadDownloads() {
        if let data = UserDefaults.standard.data(forKey: downloadsKey),
           let decoded = try? JSONDecoder().decode([DownloadItem].self, from: data) {
            downloads = decoded
        }
    }
}

// MARK: - Color Hex Helper
extension Color {
    init?(hex: String) {
        var hexSanitized = hex.trimmingCharacters(in: .whitespacesAndNewlines)
        hexSanitized = hexSanitized.replacingOccurrences(of: "#", with: "")
        var rgb: UInt64 = 0
        guard Scanner(string: hexSanitized).scanHexInt64(&rgb) else { return nil }
        let r = Double((rgb & 0xFF0000) >> 16) / 255.0
        let g = Double((rgb & 0x00FF00) >> 8) / 255.0
        let b = Double(rgb & 0x0000FF) / 255.0
        self.init(red: r, green: g, blue: b)
    }
}