import Foundation
import SwiftUI
import Combine

/// Central window manager: create, focus, move, resize, minimize, maximize, snap, workspaces.
@MainActor
final class WindowManager: ObservableObject {
    
    @Published private(set) var windows: [DesktopWindow] = []
    @Published private(set) var workspaces: [VirtualWorkspace] = []
    @Published var activeWorkspaceID: UUID
    @Published var focusedWindowID: UUID?
    
    private var nextZIndex: Int = 1
    /// Updated by DesktopRootView from GeometryReader – avoids hard-coded UIScreen sizes.
    var screenSize: CGSize = CGSize(width: 1024, height: 768)
    private let persistenceKey = "BlueDesk.Windows"
    private let workspacesKey = "BlueDesk.Workspaces"
    
    init() {
        // Default workspaces
        let work = VirtualWorkspace(name: "Arbeit", icon: "briefcase.fill")
        let gaming = VirtualWorkspace(name: "Gaming", icon: "gamecontroller.fill")
        let media = VirtualWorkspace(name: "Medien", icon: "play.rectangle.fill")
        let privateWS = VirtualWorkspace(name: "Privat", icon: "lock.fill")
        
        workspaces = [work, gaming, media, privateWS]
        activeWorkspaceID = work.id
        
        loadState()
    }
    
    // MARK: - Window CRUD
    
    @discardableResult
    func openWindow(
        title: String,
        appType: AppType,
        url: URL? = nil,
        preferredFrame: CGRect? = nil
    ) -> DesktopWindow {
        let screenBounds = CGRect(origin: .zero, size: screenSize)
        let defaultFrame = preferredFrame ?? CGRect(
            x: 80 + CGFloat(windows.count % 5) * 30,
            y: 60 + CGFloat(windows.count % 5) * 30,
            width: min(900, screenBounds.width * 0.7),
            height: min(650, screenBounds.height * 0.7)
        )
        
        var window = DesktopWindow(
            title: title,
            appType: appType,
            frame: defaultFrame,
            zIndex: nextZIndex,
            isFocused: true,
            contentURL: url ?? appType.defaultURL,
            workspaceID: activeWorkspaceID
        )
        nextZIndex += 1
        
        // Unfocus others
        for i in windows.indices {
            windows[i].isFocused = false
        }
        
        windows.append(window)
        focusedWindowID = window.id
        
        // Add to current workspace
        if let idx = workspaces.firstIndex(where: { $0.id == activeWorkspaceID }) {
            workspaces[idx].windowIDs.append(window.id)
        }
        
        saveState()
        return window
    }
    
    func closeWindow(_ id: UUID) {
        windows.removeAll { $0.id == id }
        for i in workspaces.indices {
            workspaces[i].windowIDs.removeAll { $0 == id }
        }
        if focusedWindowID == id {
            focusedWindowID = windows.filter { !$0.isMinimized && $0.workspaceID == activeWorkspaceID }
                .max(by: { $0.zIndex < $1.zIndex })?.id
        }
        saveState()
    }
    
    func focusWindow(_ id: UUID) {
        guard let idx = windows.firstIndex(where: { $0.id == id }) else { return }
        for i in windows.indices {
            windows[i].isFocused = (windows[i].id == id)
        }
        windows[idx].zIndex = nextZIndex
        nextZIndex += 1
        windows[idx].isMinimized = false
        focusedWindowID = id
        saveState()
    }
    
    // MARK: - Geometry
    
    func updateFrame(_ id: UUID, frame: CGRect) {
        guard let idx = windows.firstIndex(where: { $0.id == id }) else { return }
        var newFrame = frame
        // Enforce minimum size
        newFrame.size.width = max(windows[idx].minSize.width, newFrame.size.width)
        newFrame.size.height = max(windows[idx].minSize.height, newFrame.size.height)
        windows[idx].frame = newFrame
        windows[idx].isMaximized = false
        saveState()
    }
    
    func minimizeWindow(_ id: UUID) {
        guard let idx = windows.firstIndex(where: { $0.id == id }) else { return }
        windows[idx].isMinimized = true
        windows[idx].isFocused = false
        if focusedWindowID == id {
            focusedWindowID = windows.filter { !$0.isMinimized && $0.workspaceID == activeWorkspaceID }
                .max(by: { $0.zIndex < $1.zIndex })?.id
        }
        saveState()
    }
    
    func restoreWindow(_ id: UUID) {
        guard let idx = windows.firstIndex(where: { $0.id == id }) else { return }
        windows[idx].isMinimized = false
        focusWindow(id)
    }
    
    func toggleMaximize(_ id: UUID) {
        guard let idx = windows.firstIndex(where: { $0.id == id }) else { return }
        if windows[idx].isMaximized {
            if let saved = windows[idx].savedFrameBeforeMaximize {
                windows[idx].frame = saved
            }
            windows[idx].isMaximized = false
            windows[idx].savedFrameBeforeMaximize = nil
        } else {
            windows[idx].savedFrameBeforeMaximize = windows[idx].frame
            let screen = CGRect(origin: .zero, size: screenSize)
            // Leave space for dock (~80pt) and menu bar (~30pt)
            windows[idx].frame = CGRect(x: 0, y: 28, width: screen.width, height: screen.height - 28 - 80)
            windows[idx].isMaximized = true
        }
        focusWindow(id)
        saveState()
    }
    
    // MARK: - Snap Layouts
    
    func snapWindow(_ id: UUID, to layout: SnapLayout) {
        guard let idx = windows.firstIndex(where: { $0.id == id }) else { return }
        let screen = CGRect(origin: .zero, size: screenSize)
        let top: CGFloat = 28
        let bottom: CGFloat = 80
        let usable = CGRect(x: 0, y: top, width: screen.width, height: screen.height - top - bottom)
        let halfW = usable.width / 2
        let halfH = usable.height / 2
        
        var newFrame: CGRect
        switch layout {
        case .leftHalf:
            newFrame = CGRect(x: 0, y: top, width: halfW, height: usable.height)
        case .rightHalf:
            newFrame = CGRect(x: halfW, y: top, width: halfW, height: usable.height)
        case .topHalf:
            newFrame = CGRect(x: 0, y: top, width: usable.width, height: halfH)
        case .bottomHalf:
            newFrame = CGRect(x: 0, y: top + halfH, width: usable.width, height: halfH)
        case .topLeft:
            newFrame = CGRect(x: 0, y: top, width: halfW, height: halfH)
        case .topRight:
            newFrame = CGRect(x: halfW, y: top, width: halfW, height: halfH)
        case .bottomLeft:
            newFrame = CGRect(x: 0, y: top + halfH, width: halfW, height: halfH)
        case .bottomRight:
            newFrame = CGRect(x: halfW, y: top + halfH, width: halfW, height: halfH)
        case .fullScreen:
            newFrame = usable
        case .center:
            let w = min(900, usable.width * 0.7)
            let h = min(650, usable.height * 0.7)
            newFrame = CGRect(x: (usable.width - w) / 2, y: top + (usable.height - h) / 2, width: w, height: h)
        }
        
        windows[idx].frame = newFrame
        windows[idx].isMaximized = (layout == .fullScreen)
        windows[idx].savedFrameBeforeMaximize = nil
        focusWindow(id)
        saveState()
    }
    
    // MARK: - Workspaces
    
    func switchWorkspace(to id: UUID) {
        guard workspaces.contains(where: { $0.id == id }) else { return }
        activeWorkspaceID = id
        // Unfocus windows not in this workspace
        for i in windows.indices {
            if windows[i].workspaceID != id {
                windows[i].isFocused = false
            }
        }
        focusedWindowID = windows.filter { $0.workspaceID == id && !$0.isMinimized }
            .max(by: { $0.zIndex < $1.zIndex })?.id
        saveState()
    }
    
    func moveWindow(_ windowID: UUID, toWorkspace workspaceID: UUID) {
        guard let wIdx = windows.firstIndex(where: { $0.id == windowID }) else { return }
        let oldWS = windows[wIdx].workspaceID
        windows[wIdx].workspaceID = workspaceID
        
        if let oldIdx = workspaces.firstIndex(where: { $0.id == oldWS }) {
            workspaces[oldIdx].windowIDs.removeAll { $0 == windowID }
        }
        if let newIdx = workspaces.firstIndex(where: { $0.id == workspaceID }) {
            if !workspaces[newIdx].windowIDs.contains(windowID) {
                workspaces[newIdx].windowIDs.append(windowID)
            }
        }
        saveState()
    }
    
    // MARK: - Visible Windows
    
    var visibleWindows: [DesktopWindow] {
        windows
            .filter { $0.workspaceID == activeWorkspaceID && !$0.isMinimized }
            .sorted { $0.zIndex < $1.zIndex }
    }
    
    var minimizedWindows: [DesktopWindow] {
        windows.filter { $0.workspaceID == activeWorkspaceID && $0.isMinimized }
    }
    
    // MARK: - Persistence
    
    private func saveState() {
        // Lightweight persistence of window frames and workspaces
        if let data = try? JSONEncoder().encode(windows) {
            UserDefaults.standard.set(data, forKey: persistenceKey)
        }
        if let data = try? JSONEncoder().encode(workspaces) {
            UserDefaults.standard.set(data, forKey: workspacesKey)
        }
        UserDefaults.standard.set(activeWorkspaceID.uuidString, forKey: "BlueDesk.ActiveWorkspace")
    }
    
    private func loadState() {
        if let data = UserDefaults.standard.data(forKey: workspacesKey),
           let loaded = try? JSONDecoder().decode([VirtualWorkspace].self, from: data),
           !loaded.isEmpty {
            workspaces = loaded
        }
        if let idStr = UserDefaults.standard.string(forKey: "BlueDesk.ActiveWorkspace"),
           let id = UUID(uuidString: idStr),
           workspaces.contains(where: { $0.id == id }) {
            activeWorkspaceID = id
        }
    }
    
    /// Restore windows from last session if Settings.restoreSession is true.
    func restoreSessionIfNeeded() {
        let restore = UserDefaults.standard.bool(forKey: "BlueDesk.Settings.restoreSession")
            || (UserDefaults.standard.object(forKey: "BlueDesk.Settings.restoreSession") == nil) // default true
        guard restore else { return }
        guard windows.isEmpty else { return }
        
        if let data = UserDefaults.standard.data(forKey: persistenceKey),
           let loaded = try? JSONDecoder().decode([DesktopWindow].self, from: data),
           !loaded.isEmpty {
            windows = loaded.map { w in
                var copy = w
                copy.isFocused = false
                return copy
            }
            nextZIndex = (windows.map(\.zIndex).max() ?? 0) + 1
            focusedWindowID = windows
                .filter { $0.workspaceID == activeWorkspaceID && !$0.isMinimized }
                .max(by: { $0.zIndex < $1.zIndex })?.id
            if let fid = focusedWindowID, let idx = windows.firstIndex(where: { $0.id == fid }) {
                windows[idx].isFocused = true
            }
        }
    }
    
    func clearAllWindows() {
        windows.removeAll()
        focusedWindowID = nil
        for i in workspaces.indices {
            workspaces[i].windowIDs.removeAll()
        }
        saveState()
    }
}
