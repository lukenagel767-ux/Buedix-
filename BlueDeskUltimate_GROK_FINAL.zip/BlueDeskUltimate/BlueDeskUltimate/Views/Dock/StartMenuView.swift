import SwiftUI

struct StartMenuView: View {
    @Binding var isPresented: Bool
    @EnvironmentObject var windowManager: WindowManager
    @EnvironmentObject var settings: SettingsStore
    
    @State private var searchText = ""
    
    private var filteredApps: [AppType] {
        let all: [AppType] = [.browser, .youtube, .tiktok, .roblox, .files, .notes, .calculator, .downloads, .settings, .pdfViewer, .mediaPlayer, .calendar, .about]
        if searchText.isEmpty { return all }
        return all.filter { $0.displayName.localizedCaseInsensitiveContains(searchText) }
    }
    
    var body: some View {
        VStack(alignment: .leading, spacing: 0) {
            // Search
            HStack {
                Image(systemName: "magnifyingglass")
                    .foregroundColor(.secondary)
                TextField("Suchen…", text: $searchText)
                    .textFieldStyle(.plain)
            }
            .padding(10)
            .background(Color.primary.opacity(0.06))
            .cornerRadius(8)
            .padding()
            
            Divider()
            
            // Apps grid
            ScrollView {
                LazyVGrid(columns: [GridItem(.adaptive(minimum: 90), spacing: 12)], spacing: 16) {
                    ForEach(filteredApps) { app in
                        Button {
                            openApp(app)
                            isPresented = false
                        } label: {
                            VStack(spacing: 8) {
                                Image(systemName: app.systemImage)
                                    .font(.system(size: 28))
                                    .foregroundColor(settings.accentColor)
                                    .frame(width: 56, height: 56)
                                    .background(
                                        RoundedRectangle(cornerRadius: 12)
                                            .fill(settings.accentColor.opacity(0.12))
                                    )
                                Text(app.displayName)
                                    .font(.caption)
                                    .foregroundColor(.primary)
                                    .lineLimit(1)
                            }
                        }
                        .buttonStyle(.plain)
                    }
                }
                .padding()
            }
            .frame(maxHeight: 320)
            
            Divider()
            
            // Quick links / recent
            VStack(alignment: .leading, spacing: 6) {
                Text("Web-Dienste")
                    .font(.caption)
                    .foregroundColor(.secondary)
                    .padding(.horizontal)
                
                HStack(spacing: 12) {
                    quickLink("YouTube", url: "https://www.youtube.com", icon: "play.rectangle.fill")
                    quickLink("TikTok", url: "https://www.tiktok.com", icon: "music.note")
                    quickLink("Roblox", url: "https://www.roblox.com", icon: "gamecontroller.fill")
                    quickLink("Twitch", url: "https://www.twitch.tv", icon: "tv")
                }
                .padding(.horizontal)
                .padding(.bottom, 12)
            }
        }
        .background(
            RoundedRectangle(cornerRadius: 16)
                .fill(.ultraThinMaterial)
                .overlay(
                    RoundedRectangle(cornerRadius: 16)
                        .stroke(Color.white.opacity(0.1), lineWidth: 0.5)
                )
                .shadow(color: .black.opacity(0.4), radius: 24, y: 8)
        )
        .padding(.horizontal, 20)
    }
    
    private func openApp(_ app: AppType) {
        windowManager.openWindow(title: app.displayName, appType: app, url: app.defaultURL)
    }
    
    private func quickLink(_ title: String, url: String, icon: String) -> some View {
        Button {
            if let u = URL(string: url) {
                windowManager.openWindow(title: title, appType: .webApp, url: u)
            }
            isPresented = false
        } label: {
            Label(title, systemImage: icon)
                .font(.caption)
                .padding(.horizontal, 10)
                .padding(.vertical, 6)
                .background(Color.primary.opacity(0.08))
                .cornerRadius(8)
        }
        .buttonStyle(.plain)
    }
}