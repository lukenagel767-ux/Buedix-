import SwiftUI

struct DockView: View {
    @Binding var showStartMenu: Bool
    @EnvironmentObject var windowManager: WindowManager
    @EnvironmentObject var settings: SettingsStore
    
    var body: some View {
        HStack(spacing: 4) {
            // Start button
            DockIconButton(
                systemImage: "square.grid.2x2.fill",
                title: "Start",
                isActive: showStartMenu,
                accent: settings.accentColor
            ) {
                withAnimation { showStartMenu.toggle() }
            }
            
            Divider()
                .frame(height: 36)
                .padding(.horizontal, 4)
            
            // Pinned + open apps
            ForEach(settings.dockItems) { item in
                let isRunning = windowManager.windows.contains { $0.appType == item.appType && !$0.isMinimized }
                let isMinimized = windowManager.windows.contains { $0.appType == item.appType && $0.isMinimized }
                
                DockIconButton(
                    systemImage: item.iconName,
                    title: item.displayTitle,
                    isActive: isRunning,
                    isMinimized: isMinimized,
                    accent: settings.accentColor
                ) {
                    handleDockTap(item)
                }
                .contextMenu {
                    if isRunning || isMinimized {
                        Button("Alle Fenster schließen") {
                            windowManager.windows.filter { $0.appType == item.appType }.forEach {
                                windowManager.closeWindow($0.id)
                            }
                        }
                    }
                    Button("Aus Dock entfernen", role: .destructive) {
                        settings.unpinFromDock(item.id)
                    }
                }
            }
            
            // Minimized windows indicator
            if !windowManager.minimizedWindows.isEmpty {
                Divider().frame(height: 36).padding(.horizontal, 4)
                ForEach(windowManager.minimizedWindows.prefix(5)) { win in
                    DockIconButton(
                        systemImage: win.appType.systemImage,
                        title: win.title,
                        isActive: false,
                        isMinimized: true,
                        accent: settings.accentColor
                    ) {
                        windowManager.restoreWindow(win.id)
                    }
                }
            }
        }
        .padding(.horizontal, 14)
        .padding(.vertical, 10)
        .background(
            RoundedRectangle(cornerRadius: 18)
                .fill(.ultraThinMaterial)
                .overlay(
                    RoundedRectangle(cornerRadius: 18)
                        .stroke(Color.white.opacity(0.12), lineWidth: 0.5)
                )
                .shadow(color: .black.opacity(0.3), radius: 16, y: 4)
        )
        .padding(.horizontal, 24)
    }
    
    private func handleDockTap(_ item: DockItem) {
        // If already open and focused → minimize, else open/focus
        if let existing = windowManager.windows.first(where: { $0.appType == item.appType && $0.workspaceID == windowManager.activeWorkspaceID }) {
            if existing.isMinimized {
                windowManager.restoreWindow(existing.id)
            } else if existing.isFocused {
                windowManager.minimizeWindow(existing.id)
            } else {
                windowManager.focusWindow(existing.id)
            }
        } else {
            let title = item.displayTitle
            let url = item.customURL ?? item.appType.defaultURL
            windowManager.openWindow(title: title, appType: item.appType, url: url)
        }
    }
}

struct DockIconButton: View {
    let systemImage: String
    let title: String
    var isActive: Bool = false
    var isMinimized: Bool = false
    let accent: Color
    let action: () -> Void
    
    @State private var isHovered = false
    
    var body: some View {
        Button(action: action) {
            VStack(spacing: 3) {
                Image(systemName: systemImage)
                    .font(.system(size: 22))
                    .foregroundColor(isActive ? accent : .primary)
                    .frame(width: 44, height: 44)
                    .background(
                        RoundedRectangle(cornerRadius: 10)
                            .fill(isActive ? accent.opacity(0.18) : Color.clear)
                    )
                
                // Running indicator
                Capsule()
                    .fill(isActive ? accent : (isMinimized ? Color.gray : Color.clear))
                    .frame(width: isActive || isMinimized ? 12 : 0, height: 3)
            }
        }
        .buttonStyle(.plain)
        .help(title)
    }
}