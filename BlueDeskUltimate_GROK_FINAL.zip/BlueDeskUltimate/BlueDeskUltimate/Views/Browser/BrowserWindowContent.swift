import SwiftUI
import WebKit

struct BrowserWindowContent: View {
    let window: DesktopWindow
    
    @EnvironmentObject var settings: SettingsStore
    @StateObject private var viewModel: BrowserViewModel
    
    init(window: DesktopWindow) {
        self.window = window
        _viewModel = StateObject(wrappedValue: BrowserViewModel(initialURL: window.contentURL))
    }
    
    var body: some View {
        VStack(spacing: 0) {
            browserToolbar
            tabBar
            ZStack {
                // Each tab has its own WebView kept alive
                ForEach(viewModel.tabs) { tab in
                    if tab.id == viewModel.activeTabID {
                        TabWebView(
                            tab: tab,
                            viewModel: viewModel
                        )
                    }
                }
                
                if viewModel.isLoading {
                    VStack {
                        ProgressView(value: viewModel.progress)
                            .progressViewStyle(.linear)
                            .tint(settings.accentColor)
                        Spacer()
                    }
                }
                
                if let error = viewModel.lastError {
                    VStack(spacing: 12) {
                        Image(systemName: "exclamationmark.triangle")
                            .font(.largeTitle)
                            .foregroundColor(.orange)
                        Text("Seite konnte nicht geladen werden")
                            .font(.headline)
                        Text(error)
                            .font(.caption)
                            .foregroundColor(.secondary)
                            .multilineTextAlignment(.center)
                        Button("Erneut versuchen") {
                            viewModel.reload()
                        }
                        .buttonStyle(.borderedProminent)
                    }
                    .padding()
                    .background(.ultraThinMaterial)
                    .cornerRadius(12)
                }
            }
        }
    }
    
    private var browserToolbar: some View {
        HStack(spacing: 10) {
            Button { viewModel.goBack() } label: {
                Image(systemName: "chevron.left")
            }
            .disabled(!viewModel.canGoBack)
            .accessibilityLabel("Zurück")
            
            Button { viewModel.goForward() } label: {
                Image(systemName: "chevron.right")
            }
            .disabled(!viewModel.canGoForward)
            .accessibilityLabel("Vorwärts")
            
            Button {
                if viewModel.isLoading {
                    viewModel.stopLoading()
                } else {
                    viewModel.reload()
                }
            } label: {
                Image(systemName: viewModel.isLoading ? "xmark" : "arrow.clockwise")
            }
            .accessibilityLabel(viewModel.isLoading ? "Stopp" : "Neu laden")
            
            HStack {
                Image(systemName: "lock.fill")
                    .font(.system(size: 10))
                    .foregroundColor(.secondary)
                TextField("URL oder Suche", text: $viewModel.addressText)
                    .textFieldStyle(.plain)
                    .font(.system(size: 13))
                    .autocapitalization(.none)
                    .disableAutocorrection(true)
                    .onSubmit { viewModel.navigate(to: viewModel.addressText) }
            }
            .padding(.horizontal, 8)
            .padding(.vertical, 5)
            .background(Color.primary.opacity(0.07))
            .cornerRadius(6)
            
            Button {
                if let url = viewModel.currentURL {
                    let title = viewModel.pageTitle.isEmpty ? (url.host ?? "Lesezeichen") : viewModel.pageTitle
                    settings.addBookmark(title: title, url: url)
                }
            } label: {
                Image(systemName: "bookmark")
            }
            
            Button { viewModel.addTab() } label: {
                Image(systemName: "plus")
            }
        }
        .padding(.horizontal, 10)
        .padding(.vertical, 6)
        .font(.system(size: 14))
    }
    
    private var tabBar: some View {
        ScrollView(.horizontal, showsIndicators: false) {
            HStack(spacing: 2) {
                ForEach(viewModel.tabs) { tab in
                    HStack(spacing: 6) {
                        Text(tab.title.isEmpty ? "Neuer Tab" : tab.title)
                            .font(.system(size: 12))
                            .lineLimit(1)
                        if viewModel.tabs.count > 1 {
                            Button {
                                viewModel.closeTab(tab.id)
                            } label: {
                                Image(systemName: "xmark")
                                    .font(.system(size: 9, weight: .bold))
                            }
                            .buttonStyle(.plain)
                        }
                    }
                    .padding(.horizontal, 10)
                    .padding(.vertical, 5)
                    .background(tab.id == viewModel.activeTabID ? Color.primary.opacity(0.12) : Color.clear)
                    .cornerRadius(6)
                    .onTapGesture { viewModel.selectTab(tab.id) }
                }
            }
            .padding(.horizontal, 8)
            .padding(.vertical, 4)
        }
        .background(Color.primary.opacity(0.04))
    }
}

// MARK: - Tab Model

struct BrowserTab: Identifiable {
    let id: UUID
    var title: String
    var url: URL?
    var canGoBack: Bool
    var canGoForward: Bool
    /// Weak reference holder; actual WKWebView lives in TabWebView
    weak var webView: WKWebView?
    
    init(id: UUID = UUID(), title: String = "", url: URL? = nil) {
        self.id = id
        self.title = title
        self.url = url
        self.canGoBack = false
        self.canGoForward = false
    }
}

// MARK: - Browser ViewModel

@MainActor
final class BrowserViewModel: ObservableObject {
    @Published var tabs: [BrowserTab] = []
    @Published var activeTabID: UUID?
    @Published var addressText: String = ""
    @Published var currentURL: URL?
    @Published var isLoading = false
    @Published var progress: Double = 0
    @Published var pageTitle: String = ""
    @Published var canGoBack = false
    @Published var canGoForward = false
    @Published var lastError: String?
    
    /// Registry of live webviews per tab
    private var webViews: [UUID: WKWebView] = [:]
    
    init(initialURL: URL?) {
        let tab = BrowserTab(url: initialURL)
        tabs = [tab]
        activeTabID = tab.id
        currentURL = initialURL
        addressText = initialURL?.absoluteString ?? ""
    }
    
    func registerWebView(_ webView: WKWebView, for tabID: UUID) {
        webViews[tabID] = webView
        if let idx = tabs.firstIndex(where: { $0.id == tabID }) {
            tabs[idx].webView = webView
        }
    }
    
    func navigate(to text: String) {
        let trimmed = text.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmed.isEmpty else { return }
        lastError = nil
        
        var url: URL?
        if trimmed.hasPrefix("http://") || trimmed.hasPrefix("https://") {
            url = URL(string: trimmed)
        } else if trimmed.contains(".") && !trimmed.contains(" ") {
            url = URL(string: "https://\(trimmed)")
        } else {
            let q = trimmed.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) ?? trimmed
            url = URL(string: "https://www.google.com/search?q=\(q)")
        }
        
        guard let url else {
            lastError = "Ungültige Adresse"
            return
        }
        
        currentURL = url
        addressText = url.absoluteString
        if let idx = tabs.firstIndex(where: { $0.id == activeTabID }) {
            tabs[idx].url = url
        }
        if let id = activeTabID, let wv = webViews[id] {
            wv.load(URLRequest(url: url))
        }
    }
    
    func goBack() {
        guard let id = activeTabID, let wv = webViews[id], wv.canGoBack else { return }
        lastError = nil
        wv.goBack()
    }
    
    func goForward() {
        guard let id = activeTabID, let wv = webViews[id], wv.canGoForward else { return }
        lastError = nil
        wv.goForward()
    }
    
    func reload() {
        lastError = nil
        guard let id = activeTabID, let wv = webViews[id] else {
            if let url = currentURL {
                navigate(to: url.absoluteString)
            }
            return
        }
        wv.reload()
    }
    
    func stopLoading() {
        if let id = activeTabID, let wv = webViews[id] {
            wv.stopLoading()
        }
        isLoading = false
    }
    
    func addTab() {
        let tab = BrowserTab()
        tabs.append(tab)
        activeTabID = tab.id
        currentURL = nil
        addressText = ""
        pageTitle = ""
        canGoBack = false
        canGoForward = false
        lastError = nil
    }
    
    func selectTab(_ id: UUID) {
        activeTabID = id
        if let tab = tabs.first(where: { $0.id == id }) {
            currentURL = tab.url
            addressText = tab.url?.absoluteString ?? ""
            pageTitle = tab.title
            canGoBack = tab.canGoBack
            canGoForward = tab.canGoForward
            lastError = nil
        }
    }
    
    func closeTab(_ id: UUID) {
        webViews[id] = nil
        tabs.removeAll { $0.id == id }
        if tabs.isEmpty {
            addTab()
        } else if activeTabID == id {
            activeTabID = tabs.last?.id
            if let aid = activeTabID {
                selectTab(aid)
            }
        }
    }
    
    func updateNavigationState(for tabID: UUID, canBack: Bool, canForward: Bool, title: String?, url: URL?) {
        if let idx = tabs.firstIndex(where: { $0.id == tabID }) {
            tabs[idx].canGoBack = canBack
            tabs[idx].canGoForward = canForward
            if let title, !title.isEmpty { tabs[idx].title = title }
            if let url { tabs[idx].url = url }
        }
        if tabID == activeTabID {
            canGoBack = canBack
            canGoForward = canForward
            if let title, !title.isEmpty { pageTitle = title }
            if let url {
                currentURL = url
                addressText = url.absoluteString
            }
        }
    }
}

// MARK: - Per-Tab WebView

struct TabWebView: UIViewRepresentable {
    let tab: BrowserTab
    @ObservedObject var viewModel: BrowserViewModel
    
    func makeCoordinator() -> Coordinator {
        Coordinator(tabID: tab.id, viewModel: viewModel)
    }
    
    func makeUIView(context: Context) -> WKWebView {
        let config = WKWebViewConfiguration()
        config.allowsInlineMediaPlayback = true
        config.mediaTypesRequiringUserActionForPlayback = []
        
        let webView = WKWebView(frame: .zero, configuration: config)
        webView.navigationDelegate = context.coordinator
        webView.uiDelegate = context.coordinator
        webView.allowsBackForwardNavigationGestures = true
        webView.scrollView.contentInsetAdjustmentBehavior = .never
        
        context.coordinator.observe(webView)
        viewModel.registerWebView(webView, for: tab.id)
        
        if let url = tab.url {
            webView.load(URLRequest(url: url))
        }
        return webView
    }
    
    func updateUIView(_ webView: WKWebView, context: Context) {
        // Navigation is driven by viewModel methods calling the registered webView
    }
    
    final class Coordinator: NSObject, WKNavigationDelegate, WKUIDelegate {
        let tabID: UUID
        weak var viewModel: BrowserViewModel?
        private var progressObservation: NSKeyValueObservation?
        private var titleObservation: NSKeyValueObservation?
        private var urlObservation: NSKeyValueObservation?
        
        init(tabID: UUID, viewModel: BrowserViewModel) {
            self.tabID = tabID
            self.viewModel = viewModel
        }
        
        func observe(_ webView: WKWebView) {
            progressObservation = webView.observe(\.estimatedProgress) { [weak self] wv, _ in
                DispatchQueue.main.async {
                    guard let self, self.viewModel?.activeTabID == self.tabID else { return }
                    self.viewModel?.progress = wv.estimatedProgress
                    self.viewModel?.isLoading = wv.estimatedProgress < 1.0 && wv.isLoading
                }
            }
            titleObservation = webView.observe(\.title) { [weak self] wv, _ in
                DispatchQueue.main.async {
                    self?.viewModel?.updateNavigationState(
                        for: self?.tabID ?? UUID(),
                        canBack: wv.canGoBack,
                        canForward: wv.canGoForward,
                        title: wv.title,
                        url: wv.url
                    )
                }
            }
            urlObservation = webView.observe(\.url) { [weak self] wv, _ in
                DispatchQueue.main.async {
                    self?.viewModel?.updateNavigationState(
                        for: self?.tabID ?? UUID(),
                        canBack: wv.canGoBack,
                        canForward: wv.canGoForward,
                        title: wv.title,
                        url: wv.url
                    )
                }
            }
        }
        
        func webView(_ webView: WKWebView, didStartProvisionalNavigation navigation: WKNavigation!) {
            DispatchQueue.main.async {
                if self.viewModel?.activeTabID == self.tabID {
                    self.viewModel?.isLoading = true
                    self.viewModel?.lastError = nil
                }
            }
        }
        
        func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
            DispatchQueue.main.async {
                self.viewModel?.updateNavigationState(
                    for: self.tabID,
                    canBack: webView.canGoBack,
                    canForward: webView.canGoForward,
                    title: webView.title,
                    url: webView.url
                )
                if self.viewModel?.activeTabID == self.tabID {
                    self.viewModel?.isLoading = false
                }
            }
        }
        
        func webView(_ webView: WKWebView, didFail navigation: WKNavigation!, withError error: Error) {
            DispatchQueue.main.async {
                if self.viewModel?.activeTabID == self.tabID {
                    self.viewModel?.isLoading = false
                    self.viewModel?.lastError = error.localizedDescription
                }
            }
        }
        
        func webView(_ webView: WKWebView, didFailProvisionalNavigation navigation: WKNavigation!, withError error: Error) {
            DispatchQueue.main.async {
                if self.viewModel?.activeTabID == self.tabID {
                    self.viewModel?.isLoading = false
                    self.viewModel?.lastError = error.localizedDescription
                }
            }
        }
        
        func webView(_ webView: WKWebView, requestMediaCapturePermissionFor origin: WKSecurityOrigin, initiatedByFrame frame: WKFrameInfo, type: WKMediaCaptureType, decisionHandler: @escaping (WKPermissionDecision) -> Void) {
            decisionHandler(.prompt)
        }
    }
}
