import SwiftUI

/// On-screen trackpad controlling the internal BlueDesk pointer.
struct VirtualTouchpadView: View {
    @EnvironmentObject var inputService: InputDeviceService
    @EnvironmentObject var pointer: PointerService
    @EnvironmentObject var windowManager: WindowManager
    
    @State private var lastDrag: CGSize = .zero
    @State private var isDraggingPad = false
    @State private var longPressTriggered = false
    
    private let sensitivity: CGFloat = 1.5
    
    var body: some View {
        VStack(spacing: 6) {
            Text("Touchpad")
                .font(.caption2)
                .foregroundColor(.secondary)
            
            ZStack {
                RoundedRectangle(cornerRadius: 16)
                    .fill(.ultraThinMaterial)
                    .frame(width: 210, height: 140)
                    .overlay(
                        RoundedRectangle(cornerRadius: 16)
                            .stroke(Color.white.opacity(0.15), lineWidth: 1)
                    )
                    .shadow(color: .black.opacity(0.25), radius: 10, y: 4)
                
                Circle()
                    .fill(Color.accentColor.opacity(isDraggingPad || pointer.isPressed ? 0.5 : 0.18))
                    .frame(width: 26, height: 26)
                    .offset(x: lastDrag.width * 0.1, y: lastDrag.height * 0.1)
            }
            .gesture(padDragGesture)
            .simultaneousGesture(TapGesture(count: 2).onEnded { handleDoubleClick() })
            .simultaneousGesture(TapGesture(count: 1).onEnded { handleClick() })
            .onLongPressGesture(minimumDuration: 0.5) {
                handleLongPress()
            }
            
            HStack(spacing: 10) {
                Button("Klick") { handleClick() }
                    .buttonStyle(.bordered)
                    .controlSize(.small)
                Button("Doppelt") { handleDoubleClick() }
                    .buttonStyle(.bordered)
                    .controlSize(.small)
                Button("Ziehen") { beginWindowDragIfPossible() }
                    .buttonStyle(.bordered)
                    .controlSize(.small)
            }
            
            Text(statusText)
                .font(.system(size: 9))
                .foregroundColor(.secondary)
                .multilineTextAlignment(.center)
                .frame(width: 210)
        }
        .padding(8)
        .background(RoundedRectangle(cornerRadius: 20).fill(Color.black.opacity(0.28)))
    }
    
    private var padDragGesture: some Gesture {
        DragGesture(minimumDistance: 0)
            .onChanged { value in
                isDraggingPad = true
                let delta = CGSize(
                    width: (value.translation.width - lastDrag.width) * sensitivity,
                    height: (value.translation.height - lastDrag.height) * sensitivity
                )
                pointer.move(by: delta)
                lastDrag = value.translation
            }
            .onEnded { _ in
                isDraggingPad = false
                lastDrag = .zero
                if pointer.isDraggingWindow {
                    pointer.endWindowDrag()
                }
            }
    }
    
    private var statusText: String {
        if inputService.isMouseConnected && inputService.isKeyboardConnected {
            return "Maus+Tastatur erkannt – Touchpad kann ausgeblendet werden"
        }
        if inputService.isMouseConnected {
            return "Maus erkannt – Touchpad bleibt verfügbar"
        }
        return "Zeiger: \(Int(pointer.position.x)), \(Int(pointer.position.y))"
    }
    
    private func handleClick() {
        let isDouble = pointer.click()
        if isDouble {
            handleDoubleClick()
            return
        }
        if let win = pointer.windowUnderPointer(in: windowManager.visibleWindows) {
            windowManager.focusWindow(win.id)
            NotificationCenter.default.post(name: .blueDeskPointerClick, object: nil, userInfo: ["id": win.id])
        }
    }
    
    private func handleDoubleClick() {
        pointer.click()
        if let win = pointer.windowUnderPointer(in: windowManager.visibleWindows) {
            windowManager.focusWindow(win.id)
            // Double-click title bar → maximize/restore
            if pointer.isOverTitleBar(of: win) {
                windowManager.toggleMaximize(win.id)
            }
        }
    }
    
    private func handleLongPress() {
        longPressTriggered = true
        if let win = pointer.windowUnderPointer(in: windowManager.visibleWindows) {
            windowManager.focusWindow(win.id)
            // Long-press acts as context-menu trigger (window already has .contextMenu)
        }
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.3) { longPressTriggered = false }
    }
    
    private func beginWindowDragIfPossible() {
        if let win = pointer.windowUnderPointer(in: windowManager.visibleWindows) {
            windowManager.focusWindow(win.id)
            pointer.startWindowDrag(windowID: win.id)
        }
    }
}

/// Visual cursor on the desktop (app-internal only).
struct DesktopCursorView: View {
    @EnvironmentObject var pointer: PointerService
    @EnvironmentObject var inputService: InputDeviceService
    @EnvironmentObject var settings: SettingsStore
    
    var body: some View {
        // Show when touchpad is visible OR no external mouse (pointer still useful)
        if pointer.isVisible {
            Group {
                if pointer.isDraggingWindow {
                    Image(systemName: "arrow.up.and.down.and.arrow.left.and.right")
                } else if pointer.isPressed {
                    Image(systemName: "hand.point.up.fill")
                } else {
                    Image(systemName: "cursorarrow")
                }
            }
            .font(.system(size: 20))
            .foregroundColor(settings.accentColor)
            .shadow(color: .black.opacity(0.5), radius: 2, x: 1, y: 1)
            .position(pointer.position)
            .allowsHitTesting(false)
            .zIndex(99999)
            .animation(.interactiveSpring(response: 0.12), value: pointer.position)
        }
    }
}
