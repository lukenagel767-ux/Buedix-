import SwiftUI
import PDFKit
import UniformTypeIdentifiers

struct PDFViewerView: View {
    @State private var pdfDocument: PDFDocument?
    @State private var showImporter = false
    @State private var currentPage = 0
    @State private var pageCount = 0
    @State private var errorMessage: String?
    @State private var pdfURL: URL?
    
    var body: some View {
        VStack(spacing: 0) {
            // Toolbar
            HStack {
                Button { showImporter = true } label: {
                    Label("PDF öffnen", systemImage: "doc.badge.plus")
                }
                .buttonStyle(.bordered)
                
                if pdfDocument != nil {
                    Button {
                        goToPage(currentPage - 1)
                    } label: {
                        Image(systemName: "chevron.left")
                    }
                    .disabled(currentPage <= 0)
                    
                    Text("Seite \(currentPage + 1) / \(max(pageCount, 1))")
                        .font(.caption)
                        .monospacedDigit()
                    
                    Button {
                        goToPage(currentPage + 1)
                    } label: {
                        Image(systemName: "chevron.right")
                    }
                    .disabled(currentPage >= pageCount - 1)
                    
                    Spacer()
                    
                    if let url = pdfURL {
                        ShareLink(item: url) {
                            Image(systemName: "square.and.arrow.up")
                        }
                    }
                } else {
                    Spacer()
                }
            }
            .padding(10)
            
            Divider()
            
            if let doc = pdfDocument {
                PDFKitRepresentable(document: doc, currentPage: $currentPage)
                    .frame(maxWidth: .infinity, maxHeight: .infinity)
            } else {
                VStack(spacing: 16) {
                    Image(systemName: "doc.richtext")
                        .font(.system(size: 48))
                        .foregroundColor(.secondary)
                    Text("PDF-Viewer")
                        .font(.headline)
                    Text("Öffne eine PDF-Datei über den Dokumentenwähler. Darstellung über PDFKit (öffentliche Apple-API).")
                        .font(.caption)
                        .foregroundColor(.secondary)
                        .multilineTextAlignment(.center)
                        .padding(.horizontal, 40)
                    Button("PDF wählen") { showImporter = true }
                        .buttonStyle(.borderedProminent)
                    if let errorMessage {
                        Text(errorMessage).font(.caption).foregroundColor(.red)
                    }
                }
                .frame(maxWidth: .infinity, maxHeight: .infinity)
            }
        }
        .fileImporter(
            isPresented: $showImporter,
            allowedContentTypes: [.pdf],
            allowsMultipleSelection: false
        ) { result in
            switch result {
            case .success(let urls):
                guard let url = urls.first else { return }
                let access = url.startAccessingSecurityScopedResource()
                defer { if access { url.stopAccessingSecurityScopedResource() } }
                if let doc = PDFDocument(url: url) {
                    pdfDocument = doc
                    pageCount = doc.pageCount
                    currentPage = 0
                    pdfURL = url
                    errorMessage = nil
                } else {
                    errorMessage = "PDF konnte nicht geladen werden."
                }
            case .failure(let err):
                errorMessage = err.localizedDescription
            }
        }
    }
    
    private func goToPage(_ page: Int) {
        guard page >= 0, page < pageCount else { return }
        currentPage = page
    }
}

struct PDFKitRepresentable: UIViewRepresentable {
    let document: PDFDocument
    @Binding var currentPage: Int
    
    func makeUIView(context: Context) -> PDFView {
        let pdfView = PDFView()
        pdfView.document = document
        pdfView.autoScales = true
        pdfView.displayMode = .singlePageContinuous
        pdfView.displayDirection = .vertical
        return pdfView
    }
    
    func updateUIView(_ pdfView: PDFView, context: Context) {
        if pdfView.document !== document {
            pdfView.document = document
        }
        if let page = document.page(at: currentPage) {
            pdfView.go(to: page)
        }
    }
}
