import SwiftUI

struct AboutView: View {
    var body: some View {
        VStack(spacing: 20) {
            Image(systemName: "desktopcomputer")
                .font(.system(size: 64))
                .foregroundColor(.accentColor)
            Text("BlueDesk Ultimate")
                .font(.largeTitle.weight(.bold))
            Text("Version 1.0.0-dev")
                .foregroundColor(.secondary)
            Text("Öffentliche Apple-APIs only. Kein Jailbreak, keine privaten APIs.")
                .font(.body)
                .multilineTextAlignment(.center)
                .padding(.horizontal, 40)
            Spacer()
        }
        .padding()
    }
}
