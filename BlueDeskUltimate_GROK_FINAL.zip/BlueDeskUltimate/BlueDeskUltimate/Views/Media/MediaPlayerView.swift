import SwiftUI
import AVKit

struct MediaPlayerView: View {
    @State private var player: AVPlayer?
    @State private var showPicker = false
    @State private var errorMessage: String?
    
    var body: some View {
        VStack {
            if let player {
                VideoPlayer(player: player)
                    .frame(maxWidth: .infinity, maxHeight: .infinity)
                    .onDisappear {
                        player.pause()
                    }
            } else {
                VStack(spacing: 16) {
                    Image(systemName: "play.circle")
                        .font(.system(size: 56))
                        .foregroundColor(.secondary)
                    Text("Medienplayer")
                        .font(.headline)
                    Text("Wähle eine lokale Video- oder Audiodatei über den System-Picker. Unterstützte Formate hängen von AVFoundation ab (MP4, MOV, M4A, MP3 u. a.).")
                        .font(.caption)
                        .foregroundColor(.secondary)
                        .multilineTextAlignment(.center)
                        .padding(.horizontal, 40)
                    
                    Button("Datei öffnen") {
                        showPicker = true
                    }
                    .buttonStyle(.borderedProminent)
                    
                    if let errorMessage {
                        Text(errorMessage)
                            .font(.caption)
                            .foregroundColor(.red)
                    }
                }
                .frame(maxWidth: .infinity, maxHeight: .infinity)
            }
        }
        .fileImporter(
            isPresented: $showPicker,
            allowedContentTypes: [.movie, .audio, .mpeg4Movie, .mpeg4Audio],
            allowsMultipleSelection: false
        ) { result in
            switch result {
            case .success(let urls):
                guard let url = urls.first else { return }
                let access = url.startAccessingSecurityScopedResource()
                // Note: for longer playback one should keep the security-scoped access alive
                player = AVPlayer(url: url)
                player?.play()
                if !access {
                    errorMessage = "Kein Security-Scoped-Zugriff – Wiedergabe kann fehlschlagen."
                }
            case .failure(let err):
                errorMessage = err.localizedDescription
            }
        }
    }
}





