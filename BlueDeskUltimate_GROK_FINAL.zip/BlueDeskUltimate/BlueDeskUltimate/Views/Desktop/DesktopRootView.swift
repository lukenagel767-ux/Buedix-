import SwiftUI

struct DesktopRootView: View {
    @EnvironmentObject var windowManager: WindowManager
    @EnvironmentObject var settings: SettingsStore
    @EnvironmentObject var inputService: InputDeviceService
    @EnvironmentObject var pointer: PointerService
    
    @State private var showStartMenu = false
    @State private var showWorkspaceSwitcher = false
    @State private var searchText = ""
    
    var body: some View {
        GeometryReader { geo in
            ZStack {
                // Wallpaper
                wallpaperView
                    .ignoresSafeArea()
                
                // Windows layer
                ForEach(windowManager.visibleWindows) { window in
                    WindowChromeView(window: window)
                        .zIndex(Double(window.zIndex))
                        .transition(.opacity.combined(with: .scale(scale: 0.95)))
                }
                
                // Top menu bar
                VStack {
                    TopMenuBar(
                        showStartMenu: $showStartMenu,
                        showWorkspaceSwitcher: $showWorkspaceSwitcher,
                        searchText: $searchText
                    )
                    Spacer()
                }
                
                // Dock
                VStack {
                    Spacer()
                    DockView(showStartMenu: $showStartMenu)
                        .padding(.bottom, 8)
                }
                
                // Start Menu overlay
                if showStartMenu {
                    Color.black.opacity(0.35)
                        .ignoresSafeArea()
                        .onTapGesture { withAnimation(.easeOut(duration: 0.2)) { showStartMenu = false } }
                    
                    VStack {
                        Spacer()
                        StartMenuView(isPresented: $showStartMenu)
                            .frame(maxWidth: 420)
                            .padding(.bottom, 90)
                            .transition(.move(edge: .bottom).combined(with: .opacity))
                    }
                }
                
                // Workspace switcher
                if showWorkspaceSwitcher {
                    WorkspaceSwitcherView(isPresented: $showWorkspaceSwitcher)
                        .transition(.opacity)
                }
                
                // Virtual Touchpad
                if inputService.shouldShowVirtualTouchpad && settings.settings.showVirtualTouchpad {
                    VStack {
                        Spacer()
                        HStack {
                            Spacer()
                            VirtualTouchpadView()
                                .padding(.trailing, 24)
                                .padding(.bottom, 100)
                        }
                    }
                    .transition(.opacity)
                }
                
                // Internal desktop cursor
                DesktopCursorView()
            }
            .animation(.easeInOut(duration: 0.2), value: showStartMenu)
            .animation(.easeInOut(duration: 0.2), value: inputService.shouldShowVirtualTouchpad)
            .onAppear {
                pointer.screenBounds = CGRect(origin: .zero, size: geo.size)
                windowManager.screenSize = geo.size
                inputService.refreshDeviceStatus()
                windowManager.restoreSessionIfNeeded()
            }
            .onChange(of: geo.size) { _, newSize in
                pointer.screenBounds = CGRect(origin: .zero, size: newSize)
                windowManager.screenSize = newSize
            }
            .onReceive(NotificationCenter.default.publisher(for: UIApplication.didBecomeActiveNotification)) { _ in
                inputService.refreshDeviceStatus()
            }
        }
    }
    
    @ViewBuilder
    private var wallpaperView: some View {
        if settings.settings.isDarkMode {
            LinearGradient(
                colors: [
                    Color(red: 0.05, green: 0.08, blue: 0.15),
                    Color(red: 0.08, green: 0.12, blue: 0.22),
                    Color(red: 0.04, green: 0.06, blue: 0.12)
                ],
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            )
        } else {
            LinearGradient(
                colors: [
                    Color(red: 0.85, green: 0.90, blue: 0.98),
                    Color(red: 0.75, green: 0.82, blue: 0.95)
                ],
                startPoint: .top,
                endPoint: .bottom
            )
        }
    }
}
