import SwiftUI

struct TopMenuBar: View {
    @Binding var showStartMenu: Bool
    @Binding var showWorkspaceSwitcher: Bool
    @Binding var searchText: String
    
    @EnvironmentObject var windowManager: WindowManager
    @EnvironmentObject var settings: SettingsStore
    @EnvironmentObject var inputService: InputDeviceService
    
    var body: some View {
        HStack(spacing: 16) {
            // Workspace indicator
            Button {
                withAnimation { showWorkspaceSwitcher.toggle() }
            } label: {
                HStack(spacing: 6) {
                    Image(systemName: currentWorkspace?.icon ?? "desktopcomputer")
                    Text(currentWorkspace?.name ?? "Desktop")
                        .font(.system(size: 13, weight: .medium))
                }
                .foregroundColor(.primary)
            }
            .buttonStyle(.plain)
            
            Spacer()
            
            // Global search (simplified)
            HStack {
                Image(systemName: "magnifyingglass")
                    .font(.system(size: 12))
                    .foregroundColor(.secondary)
                TextField("BlueDesk suchen…", text: $searchText)
                    .textFieldStyle(.plain)
                    .font(.system(size: 13))
                    .frame(maxWidth: 220)
                    .onSubmit { performSearch() }
            }
            .padding(.horizontal, 10)
            .padding(.vertical, 5)
            .background(Color.primary.opacity(0.08))
            .cornerRadius(8)
            
            Spacer()
            
            // Input status
            HStack(spacing: 8) {
                if inputService.isMouseConnected {
                    Image(systemName: "computermouse")
                        .foregroundColor(settings.accentColor)
                        .help("Maus verbunden")
                }
                if inputService.isKeyboardConnected {
                    Image(systemName: "keyboard")
                        .foregroundColor(settings.accentColor)
                        .help("Tastatur verbunden")
                }
                if !inputService.shouldShowVirtualTouchpad {
                    Text("Extern")
                        .font(.caption2)
                        .foregroundColor(.secondary)
                }
            }
            .font(.system(size: 13))
            
            // Clock
            Text(Date(), style: .time)
                .font(.system(size: 13, weight: .medium).monospacedDigit())
                .padding(.trailing, 8)
        }
        .padding(.horizontal, 16)
        .frame(height: 28)
        .background(.ultraThinMaterial)
    }
    
    private var currentWorkspace: VirtualWorkspace? {
        windowManager.workspaces.first { $0.id == windowManager.activeWorkspaceID }
    }
    
    private func performSearch() {
        let q = searchText.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !q.isEmpty else { return }
        
        // Search in notes
        if let note = settings.notes.first(where: { $0.title.localizedCaseInsensitiveContains(q) || $0.content.localizedCaseInsensitiveContains(q) }) {
            windowManager.openWindow(title: note.title, appType: .notes)
            return
        }
        
        // Search bookmarks
        if let bm = settings.bookmarks.first(where: { $0.title.localizedCaseInsensitiveContains(q) }) {
            windowManager.openWindow(title: bm.title, appType: .browser, url: bm.url)
            return
        }
        
        // Fallback: open browser with search
        let engine = settings.settings.defaultSearchEngine
        if let url = URL(string: engine + q.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed)!) {
            windowManager.openWindow(title: "Suche: \(q)", appType: .browser, url: url)
        }
        searchText = ""
    }
}

struct WorkspaceSwitcherView: View {
    @Binding var isPresented: Bool
    @EnvironmentObject var windowManager: WindowManager
    @EnvironmentObject var settings: SettingsStore
    
    var body: some View {
        ZStack {
            Color.black.opacity(0.5)
                .ignoresSafeArea()
                .onTapGesture { isPresented = false }
            
            HStack(spacing: 20) {
                ForEach(windowManager.workspaces) { ws in
                    Button {
                        windowManager.switchWorkspace(to: ws.id)
                        isPresented = false
                    } label: {
                        VStack(spacing: 10) {
                            Image(systemName: ws.icon)
                                .font(.system(size: 32))
                                .foregroundColor(ws.id == windowManager.activeWorkspaceID ? settings.accentColor : .primary)
                            Text(ws.name)
                                .font(.headline)
                            Text("\(ws.windowIDs.count) Fenster")
                                .font(.caption)
                                .foregroundColor(.secondary)
                        }
                        .frame(width: 120, height: 120)
                        .background(
                            RoundedRectangle(cornerRadius: 16)
                                .fill(ws.id == windowManager.activeWorkspaceID ? settings.accentColor.opacity(0.15) : Color.primary.opacity(0.08))
                        )
                        .overlay(
                            RoundedRectangle(cornerRadius: 16)
                                .stroke(ws.id == windowManager.activeWorkspaceID ? settings.accentColor : Color.clear, lineWidth: 2)
                        )
                    }
                    .buttonStyle(.plain)
                }
            }
            .padding(30)
            .background(.ultraThinMaterial)
            .cornerRadius(20)
        }
    }
}