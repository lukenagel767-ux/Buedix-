import SwiftUI

struct CalculatorView: View {
    @State private var display = "0"
    @State private var previousValue: Double?
    @State private var currentOperation: String?
    @State private var shouldResetDisplay = false
    @State private var history: [String] = []
    
    private let buttons: [[String]] = [
        ["C", "±", "%", "÷"],
        ["7", "8", "9", "×"],
        ["4", "5", "6", "−"],
        ["1", "2", "3", "+"],
        ["0", ".", "=", ""]
    ]
    
    var body: some View {
        VStack(spacing: 8) {
            // Display
            HStack {
                Spacer()
                Text(display)
                    .font(.system(size: 42, weight: .light, design: .rounded))
                    .lineLimit(1)
                    .minimumScaleFactor(0.5)
            }
            .padding(.horizontal, 16)
            .padding(.vertical, 12)
            .frame(maxWidth: .infinity)
            .background(Color.primary.opacity(0.06))
            .cornerRadius(10)
            
            // History
            if !history.isEmpty {
                ScrollView {
                    VStack(alignment: .trailing, spacing: 2) {
                        ForEach(history.suffix(5), id: \.self) { entry in
                            Text(entry)
                                .font(.caption)
                                .foregroundColor(.secondary)
                        }
                    }
                    .frame(maxWidth: .infinity, alignment: .trailing)
                }
                .frame(height: 50)
            }
            
            // Buttons
            ForEach(buttons, id: \.self) { row in
                HStack(spacing: 8) {
                    ForEach(row.filter { !$0.isEmpty }, id: \.self) { label in
                        CalcButton(label: label, isOp: isOperator(label)) {
                            handleTap(label)
                        }
                    }
                }
            }
        }
        .padding(12)
    }
    
    private func isOperator(_ s: String) -> Bool {
        ["÷", "×", "−", "+", "="].contains(s)
    }
    
    private func handleTap(_ label: String) {
        switch label {
        case "C":
            display = "0"
            previousValue = nil
            currentOperation = nil
            shouldResetDisplay = false
        case "±":
            if let val = Double(display) {
                display = format(-val)
            }
        case "%":
            if let val = Double(display) {
                display = format(val / 100)
            }
        case "÷", "×", "−", "+":
            if let val = Double(display) {
                if let prev = previousValue, let op = currentOperation {
                    let result = apply(op, prev, val)
                    display = format(result)
                    previousValue = result
                    history.append("\(format(prev)) \(op) \(format(val)) = \(format(result))")
                } else {
                    previousValue = val
                }
            }
            currentOperation = label
            shouldResetDisplay = true
        case "=":
            if let val = Double(display), let prev = previousValue, let op = currentOperation {
                let result = apply(op, prev, val)
                history.append("\(format(prev)) \(op) \(format(val)) = \(format(result))")
                display = format(result)
                previousValue = nil
                currentOperation = nil
                shouldResetDisplay = true
            }
        case ".":
            if shouldResetDisplay {
                display = "0."
                shouldResetDisplay = false
            } else if !display.contains(".") {
                display += "."
            }
        default: // digits
            if shouldResetDisplay || display == "0" {
                display = label
                shouldResetDisplay = false
            } else {
                display += label
            }
        }
    }
    
    private func apply(_ op: String, _ a: Double, _ b: Double) -> Double {
        switch op {
        case "÷": return b == 0 ? 0 : a / b
        case "×": return a * b
        case "−": return a - b
        case "+": return a + b
        default: return b
        }
    }
    
    private func format(_ value: Double) -> String {
        if value.truncatingRemainder(dividingBy: 1) == 0 {
            return String(format: "%.0f", value)
        }
        return String(format: "%.8g", value)
    }
}

struct CalcButton: View {
    let label: String
    let isOp: Bool
    let action: () -> Void
    
    var body: some View {
        Button(action: action) {
            Text(label)
                .font(.system(size: 22, weight: .medium, design: .rounded))
                .frame(maxWidth: .infinity)
                .frame(height: 48)
                .background(isOp ? Color.accentColor.opacity(0.85) : Color.primary.opacity(0.1))
                .foregroundColor(isOp ? .white : .primary)
                .cornerRadius(10)
        }
        .buttonStyle(.plain)
    }
}