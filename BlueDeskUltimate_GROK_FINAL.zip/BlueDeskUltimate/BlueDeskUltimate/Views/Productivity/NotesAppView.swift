import SwiftUI

/// iOS/iPadOS-compatible notes app (no HSplitView – that is macOS-only).
struct NotesAppView: View {
    @EnvironmentObject var settings: SettingsStore
    @State private var selectedNoteID: UUID?
    @State private var editTitle = ""
    @State private var editContent = ""
    @State private var columnVisibility: NavigationSplitViewVisibility = .all
    
    var body: some View {
        NavigationSplitView(columnVisibility: $columnVisibility) {
            noteList
                .navigationTitle("Notizen")
                .toolbar {
                    ToolbarItem(placement: .primaryAction) {
                        Button {
                            let note = Note()
                            settings.addNote(note)
                            selectedNoteID = note.id
                            editTitle = note.title
                            editContent = note.content
                        } label: {
                            Image(systemName: "plus")
                        }
                    }
                }
        } detail: {
            if let id = selectedNoteID,
               let note = settings.notes.first(where: { $0.id == id }) {
                noteEditor(for: note)
            } else {
                VStack(spacing: 12) {
                    Image(systemName: "note.text")
                        .font(.system(size: 40))
                        .foregroundColor(.secondary)
                    Text("Keine Notiz ausgewählt")
                        .font(.headline)
                    Text("Wähle eine Notiz aus oder erstelle eine neue.")
                        .font(.caption)
                        .foregroundColor(.secondary)
                }
                .frame(maxWidth: .infinity, maxHeight: .infinity)
            }
        }
        .navigationSplitViewStyle(.balanced)
    }
    
    private var noteList: some View {
        List(selection: $selectedNoteID) {
            ForEach(settings.notes) { note in
                VStack(alignment: .leading, spacing: 2) {
                    Text(note.title.isEmpty ? "Ohne Titel" : note.title)
                        .font(.body.weight(.medium))
                        .lineLimit(1)
                    Text(note.content.isEmpty ? "Leer" : String(note.content.prefix(80)))
                        .font(.caption)
                        .foregroundColor(.secondary)
                        .lineLimit(2)
                }
                .tag(note.id)
                .contextMenu {
                    Button("Löschen", role: .destructive) {
                        settings.deleteNote(note.id)
                        if selectedNoteID == note.id {
                            selectedNoteID = nil
                        }
                    }
                }
            }
            .onDelete { indexSet in
                for index in indexSet {
                    let id = settings.notes[index].id
                    settings.deleteNote(id)
                    if selectedNoteID == id { selectedNoteID = nil }
                }
            }
        }
        .listStyle(.sidebar)
    }
    
    @ViewBuilder
    private func noteEditor(for note: Note) -> some View {
        VStack(alignment: .leading, spacing: 0) {
            TextField("Titel", text: $editTitle)
                .font(.title2.weight(.semibold))
                .padding()
                .onChange(of: editTitle) { _, newValue in
                    var updated = note
                    updated.title = newValue
                    settings.updateNote(updated)
                }
            
            Divider()
            
            TextEditor(text: $editContent)
                .padding(8)
                .onChange(of: editContent) { _, newValue in
                    var updated = note
                    updated.content = newValue
                    settings.updateNote(updated)
                }
        }
        .onAppear {
            editTitle = note.title
            editContent = note.content
        }
        .onChange(of: selectedNoteID) { _, newID in
            if let n = settings.notes.first(where: { $0.id == newID }) {
                editTitle = n.title
                editContent = n.content
            }
        }
        .toolbar {
            ToolbarItem(placement: .primaryAction) {
                ShareLink(item: "\(editTitle)\n\n\(editContent)") {
                    Image(systemName: "square.and.arrow.up")
                }
            }
        }
    }
}
