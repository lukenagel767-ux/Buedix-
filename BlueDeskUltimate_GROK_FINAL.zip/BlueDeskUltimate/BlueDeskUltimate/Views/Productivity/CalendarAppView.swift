import SwiftUI
import EventKit

struct CalendarAppView: View {
    @StateObject private var store = CalendarStore()
    @State private var showPermissionAlert = false
    
    var body: some View {
        VStack(spacing: 0) {
            HStack {
                Text("Kalender")
                    .font(.headline)
                Spacer()
                if store.authorizationStatus == .fullAccess || store.authorizationStatus == .authorized {
                    Button {
                        Task { await store.reload() }
                    } label: {
                        Image(systemName: "arrow.clockwise")
                    }
                }
            }
            .padding()
            
            Divider()
            
            switch store.authorizationStatus {
            case .notDetermined:
                VStack(spacing: 16) {
                    Image(systemName: "calendar")
                        .font(.system(size: 48))
                        .foregroundColor(.secondary)
                    Text("Kalenderzugriff")
                        .font(.headline)
                    Text("BlueDesk benötigt Zugriff auf deinen Kalender, um Termine anzuzeigen. Die Berechtigung wird nur bei Nutzung angefordert.")
                        .font(.caption)
                        .foregroundColor(.secondary)
                        .multilineTextAlignment(.center)
                        .padding(.horizontal, 40)
                    Button("Zugriff anfordern") {
                        Task {
                            let granted = await store.requestAccess()
                            if !granted { showPermissionAlert = true }
                        }
                    }
                    .buttonStyle(.borderedProminent)
                }
                .frame(maxWidth: .infinity, maxHeight: .infinity)
                
            case .denied, .restricted:
                VStack(spacing: 12) {
                    Image(systemName: "calendar.badge.exclamationmark")
                        .font(.system(size: 40))
                        .foregroundColor(.orange)
                    Text("Kein Zugriff")
                        .font(.headline)
                    Text("Aktiviere den Kalenderzugriff in den iOS-Einstellungen → BlueDesk Ultimate.")
                        .font(.caption)
                        .foregroundColor(.secondary)
                        .multilineTextAlignment(.center)
                        .padding(.horizontal, 30)
                }
                .frame(maxWidth: .infinity, maxHeight: .infinity)
                
            default:
                if store.events.isEmpty {
                    VStack(spacing: 12) {
                        Image(systemName: "calendar")
                            .font(.system(size: 40))
                            .foregroundColor(.secondary)
                        Text("Keine Termine in den nächsten 14 Tagen")
                            .foregroundColor(.secondary)
                    }
                    .frame(maxWidth: .infinity, maxHeight: .infinity)
                } else {
                    List(store.events, id: \.eventIdentifier) { event in
                        VStack(alignment: .leading, spacing: 4) {
                            Text(event.title ?? "Ohne Titel")
                                .font(.body.weight(.medium))
                            if let start = event.startDate {
                                Text(start.formatted(date: .abbreviated, time: .shortened))
                                    .font(.caption)
                                    .foregroundColor(.secondary)
                            }
                            if let loc = event.location, !loc.isEmpty {
                                Text(loc)
                                    .font(.caption2)
                                    .foregroundColor(.secondary)
                            }
                        }
                    }
                    .listStyle(.plain)
                }
            }
        }
        .task {
            if store.authorizationStatus == .fullAccess || store.authorizationStatus == .authorized {
                await store.reload()
            }
        }
        .alert("Berechtigung verweigert", isPresented: $showPermissionAlert) {
            Button("OK", role: .cancel) {}
        } message: {
            Text("Ohne Kalenderberechtigung können keine Termine angezeigt werden.")
        }
    }
}

@MainActor
final class CalendarStore: ObservableObject {
    @Published var events: [EKEvent] = []
    @Published var authorizationStatus: EKAuthorizationStatus = .notDetermined
    
    private let eventStore = EKEventStore()
    
    init() {
        refreshStatus()
    }
    
    func refreshStatus() {
        if #available(iOS 17.0, *) {
            authorizationStatus = EKEventStore.authorizationStatus(for: .event)
        } else {
            authorizationStatus = EKEventStore.authorizationStatus(for: .event)
        }
    }
    
    func requestAccess() async -> Bool {
        do {
            let granted: Bool
            if #available(iOS 17.0, *) {
                granted = try await eventStore.requestFullAccessToEvents()
            } else {
                granted = try await eventStore.requestAccess(to: .event)
            }
            refreshStatus()
            if granted {
                await reload()
            }
            return granted
        } catch {
            refreshStatus()
            return false
        }
    }
    
    func reload() async {
        refreshStatus()
        let cal = Calendar.current
        let start = cal.startOfDay(for: Date())
        guard let end = cal.date(byAdding: .day, value: 14, to: start) else { return }
        
        let predicate = eventStore.predicateForEvents(withStart: start, end: end, calendars: nil)
        let result = eventStore.events(matching: predicate)
        events = result.sorted { ($0.startDate ?? .distantPast) < ($1.startDate ?? .distantPast) }
    }
}
