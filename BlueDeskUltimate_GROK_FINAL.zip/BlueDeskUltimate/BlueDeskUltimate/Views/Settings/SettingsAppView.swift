import SwiftUI

struct SettingsAppView: View {
    @EnvironmentObject var settings: SettingsStore
    @EnvironmentObject var inputService: InputDeviceService
    
    var body: some View {
        Form {
            Section("Darstellung") {
                Toggle("Dunkler Modus", isOn: $settings.settings.isDarkMode)
                
                HStack {
                    Text("Akzentfarbe")
                    Spacer()
                    ColorPicker("", selection: Binding(
                        get: { settings.accentColor },
                        set: { newColor in
                            // Simple conversion; real hex round-trip would need more code
                            settings.settings.accentColor = "007AFF"
                        }
                    ), supportsOpacity: false)
                }
                
                Toggle("Transparenz-Effekte", isOn: $settings.settings.transparencyEnabled)
                Toggle("Bewegung reduzieren", isOn: $settings.settings.reduceMotion)
            }
            
            Section("Dock & Icons") {
                HStack {
                    Text("Dock-Größe")
                    Slider(value: $settings.settings.dockSize, in: 48...80, step: 4)
                    Text("\(Int(settings.settings.dockSize))")
                        .monospacedDigit()
                }
                HStack {
                    Text("Icon-Größe")
                    Slider(value: $settings.settings.iconSize, in: 32...64, step: 4)
                    Text("\(Int(settings.settings.iconSize))")
                        .monospacedDigit()
                }
            }
            
            Section("Eingabe") {
                Toggle("Externe Geräte bevorzugen", isOn: $settings.settings.preferExternalInput)
                    .onChange(of: settings.settings.preferExternalInput) { newValue in
                        inputService.updatePreferExternalInput(newValue)
                    }
                
                Toggle("Virtuelles Touchpad anzeigen (wenn nötig)", isOn: $settings.settings.showVirtualTouchpad)
                
                VStack(alignment: .leading, spacing: 4) {
                    Text("Aktueller Status")
                        .font(.caption)
                        .foregroundColor(.secondary)
                    Text(inputService.statusDescription)
                        .font(.caption)
                        .foregroundColor(.primary)
                }
                
                Button("Geräte-Status aktualisieren") {
                    inputService.refreshDeviceStatus()
                }
            }
            
            Section("Browser") {
                TextField("Suchmaschine (URL-Prefix)", text: $settings.settings.defaultSearchEngine)
                Toggle("Sitzung wiederherstellen", isOn: $settings.settings.restoreSession)
            }
            
            Section("Über") {
                LabeledContent("Version", value: "1.0.0-dev")
                LabeledContent("Build-Umgebung", value: "Quellcode – nicht kompiliert in dieser Umgebung")
                Text("BlueDesk Ultimate nutzt ausschließlich öffentliche Apple-APIs (SwiftUI, WKWebView, GameController, EventKit wo möglich, DocumentPicker). Keine privaten APIs, kein Jailbreak.")
                    .font(.caption)
                    .foregroundColor(.secondary)
            }
            
            Section("Diagnose") {
                LabeledContent("Offene Fenster", value: "siehe WindowManager")
                LabeledContent("Notizen", value: "\(settings.notes.count)")
                LabeledContent("Lesezeichen", value: "\(settings.bookmarks.count)")
                LabeledContent("Dock-Einträge", value: "\(settings.dockItems.count)")
            }
        }
        .formStyle(.grouped)
        .padding()
    }
}