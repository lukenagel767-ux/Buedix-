import SwiftUI

struct WindowChromeView: View {
    let window: DesktopWindow
    
    @EnvironmentObject var windowManager: WindowManager
    @EnvironmentObject var settings: SettingsStore
    
    @State private var dragOffset: CGSize = .zero
    @State private var isDragging = false
    @State private var resizeOffset: CGSize = .zero
    @State private var isResizing = false
    @State private var showContextMenu = false
    
    private var currentFrame: CGRect {
        var f = window.frame
        f.origin.x += dragOffset.width
        f.origin.y += dragOffset.height
        f.size.width += resizeOffset.width
        f.size.height += resizeOffset.height
        return f
    }
    
    var body: some View {
        ZStack(alignment: .topLeading) {
            // Window background + content
            VStack(spacing: 0) {
                titleBar
                Divider()
                windowContent
                    .frame(maxWidth: .infinity, maxHeight: .infinity)
            }
            .background(
                RoundedRectangle(cornerRadius: 12)
                    .fill(settings.settings.isDarkMode ? Color(white: 0.12) : Color(white: 0.96))
            )
            .clipShape(RoundedRectangle(cornerRadius: 12))
            .overlay(
                RoundedRectangle(cornerRadius: 12)
                    .stroke(window.isFocused ? settings.accentColor.opacity(0.8) : Color.gray.opacity(0.3), lineWidth: window.isFocused ? 1.5 : 0.5)
            )
            .shadow(color: .black.opacity(window.isFocused ? 0.35 : 0.18), radius: window.isFocused ? 18 : 8, y: 6)
            
            // Resize handle (bottom-right)
            resizeHandle
        }
        .frame(width: currentFrame.width, height: currentFrame.height)
        .position(x: currentFrame.midX, y: currentFrame.midY)
        .onTapGesture {
            windowManager.focusWindow(window.id)
        }
        .contextMenu {
            Button("Minimieren") { windowManager.minimizeWindow(window.id) }
            Button(window.isMaximized ? "Wiederherstellen" : "Maximieren") {
                windowManager.toggleMaximize(window.id)
            }
            Divider()
            Menu("Snap") {
                Button("Linke Hälfte") { windowManager.snapWindow(window.id, to: .leftHalf) }
                Button("Rechte Hälfte") { windowManager.snapWindow(window.id, to: .rightHalf) }
                Button("Obere Hälfte") { windowManager.snapWindow(window.id, to: .topHalf) }
                Button("Untere Hälfte") { windowManager.snapWindow(window.id, to: .bottomHalf) }
                Divider()
                Button("Oben Links") { windowManager.snapWindow(window.id, to: .topLeft) }
                Button("Oben Rechts") { windowManager.snapWindow(window.id, to: .topRight) }
                Button("Unten Links") { windowManager.snapWindow(window.id, to: .bottomLeft) }
                Button("Unten Rechts") { windowManager.snapWindow(window.id, to: .bottomRight) }
                Divider()
                Button("Vollbild") { windowManager.snapWindow(window.id, to: .fullScreen) }
                Button("Zentrieren") { windowManager.snapWindow(window.id, to: .center) }
            }
            Divider()
            Button("Schließen", role: .destructive) { windowManager.closeWindow(window.id) }
        }
        .animation(settings.settings.reduceMotion ? nil : .interactiveSpring(), value: window.frame)
        .onReceive(NotificationCenter.default.publisher(for: .blueDeskPointerDragWindow)) { note in
            guard let id = note.userInfo?["id"] as? UUID, id == window.id,
                  let delta = note.userInfo?["delta"] as? CGSize else { return }
            var newFrame = window.frame
            newFrame.origin.x += delta.width
            newFrame.origin.y += delta.height
            windowManager.updateFrame(window.id, frame: newFrame)
        }

    }
    
    // MARK: - Title Bar
    
    private var titleBar: some View {
        HStack(spacing: 8) {
            // Traffic lights
            HStack(spacing: 6) {
                Circle()
                    .fill(Color.red.opacity(0.9))
                    .frame(width: 12, height: 12)
                    .overlay(Image(systemName: "xmark").font(.system(size: 6, weight: .bold)).foregroundColor(.black.opacity(0.6)))
                    .onTapGesture { windowManager.closeWindow(window.id) }
                
                Circle()
                    .fill(Color.yellow.opacity(0.9))
                    .frame(width: 12, height: 12)
                    .overlay(Image(systemName: "minus").font(.system(size: 6, weight: .bold)).foregroundColor(.black.opacity(0.6)))
                    .onTapGesture { windowManager.minimizeWindow(window.id) }
                
                Circle()
                    .fill(Color.green.opacity(0.9))
                    .frame(width: 12, height: 12)
                    .overlay(Image(systemName: "arrow.up.left.and.arrow.down.right").font(.system(size: 5, weight: .bold)).foregroundColor(.black.opacity(0.6)))
                    .onTapGesture { windowManager.toggleMaximize(window.id) }
            }
            .padding(.leading, 10)
            
            Spacer()
            
            Text(window.title)
                .font(.system(size: 13, weight: .medium))
                .foregroundColor(settings.settings.isDarkMode ? .white.opacity(0.9) : .black.opacity(0.8))
                .lineLimit(1)
            
            Spacer()
            
            Image(systemName: window.appType.systemImage)
                .font(.system(size: 12))
                .foregroundColor(settings.accentColor)
                .padding(.trailing, 12)
        }
        .frame(height: 36)
        .background(settings.settings.isDarkMode ? Color(white: 0.16) : Color(white: 0.92))
        .gesture(
            DragGesture()
                .onChanged { value in
                    if !isDragging {
                        isDragging = true
                        windowManager.focusWindow(window.id)
                    }
                    dragOffset = value.translation
                }
                .onEnded { value in
                    var newFrame = window.frame
                    newFrame.origin.x += value.translation.width
                    newFrame.origin.y += value.translation.height
                    // Keep on screen roughly
                    newFrame.origin.x = max(-newFrame.width + 80, min(windowManager.screenSize.width - 80, newFrame.origin.x))
                    newFrame.origin.y = max(20, min(windowManager.screenSize.height - 100, newFrame.origin.y))
                    windowManager.updateFrame(window.id, frame: newFrame)
                    dragOffset = .zero
                    isDragging = false
                }
        )
    }
    
    // MARK: - Content
    
    @ViewBuilder
    private var windowContent: some View {
        switch window.appType {
        case .browser, .youtube, .tiktok, .roblox, .webApp:
            BrowserWindowContent(window: window)
        case .files:
            FilesAppView()
        case .notes:
            NotesAppView()
        case .calculator:
            CalculatorView()
        case .settings:
            SettingsAppView()
        case .downloads:
            DownloadsView()
        case .pdfViewer:
            PDFViewerView()
        case .mediaPlayer:
            MediaPlayerView()
        case .calendar:
            CalendarAppView()
        case .about:
            AboutView()
        }
    }
    
    // MARK: - Resize Handle
    
    private var resizeHandle: some View {
        VStack {
            Spacer()
            HStack {
                Spacer()
                Image(systemName: "arrow.up.left.and.arrow.down.right")
                    .font(.system(size: 10))
                    .foregroundColor(.gray.opacity(0.6))
                    .frame(width: 20, height: 20)
                    .contentShape(Rectangle())
                    .gesture(
                        DragGesture()
                            .onChanged { value in
                                if !isResizing {
                                    isResizing = true
                                    windowManager.focusWindow(window.id)
                                }
                                resizeOffset = value.translation
                            }
                            .onEnded { value in
                                var newFrame = window.frame
                                newFrame.size.width += value.translation.width
                                newFrame.size.height += value.translation.height
                                windowManager.updateFrame(window.id, frame: newFrame)
                                resizeOffset = .zero
                                isResizing = false
                            }
                    )
            }
        }
        .padding(6)
    }
}