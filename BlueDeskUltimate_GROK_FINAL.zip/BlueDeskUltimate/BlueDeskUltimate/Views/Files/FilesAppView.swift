import SwiftUI
import UniformTypeIdentifiers

struct FilesAppView: View {
    @State private var documents: [FileItem] = []
    @State private var selectedItems: Set<UUID> = []
    @State private var showImporter = false
    @State private var searchText = ""
    @State private var sortByName = true
    @State private var errorMessage: String?
    @State private var shareItem: ShareItem?
    
    var body: some View {
        VStack(spacing: 0) {
            HStack {
                Button { showImporter = true } label: {
                    Label("Öffnen", systemImage: "folder.badge.plus")
                }
                .buttonStyle(.bordered)
                
                if !selectedItems.isEmpty {
                    Button {
                        shareSelected()
                    } label: {
                        Label("Teilen", systemImage: "square.and.arrow.up")
                    }
                    .buttonStyle(.bordered)
                    
                    Button(role: .destructive) {
                        documents.removeAll { selectedItems.contains($0.id) }
                        selectedItems.removeAll()
                    } label: {
                        Label("Entfernen", systemImage: "trash")
                    }
                    .buttonStyle(.bordered)
                }
                
                Spacer()
                
                TextField("Suchen", text: $searchText)
                    .textFieldStyle(.roundedBorder)
                    .frame(maxWidth: 180)
                
                Picker("Sort", selection: $sortByName) {
                    Text("Name").tag(true)
                    Text("Datum").tag(false)
                }
                .pickerStyle(.segmented)
                .frame(width: 120)
            }
            .padding(10)
            
            Divider()
            
            if documents.isEmpty {
                VStack(spacing: 16) {
                    Image(systemName: "folder")
                        .font(.system(size: 48))
                        .foregroundColor(.secondary)
                    Text("Keine Dateien")
                        .font(.headline)
                    Text("Tippe auf „Öffnen“, um Dateien über den System-Dokumentenwähler hinzuzufügen.\nNur vom Benutzer freigegebene Dateien/Ordner sind zugänglich (iOS-Sandbox).")
                        .font(.caption)
                        .foregroundColor(.secondary)
                        .multilineTextAlignment(.center)
                        .padding(.horizontal, 40)
                    Button("Datei oder Ordner wählen") { showImporter = true }
                        .buttonStyle(.borderedProminent)
                }
                .frame(maxWidth: .infinity, maxHeight: .infinity)
            } else {
                List(selection: $selectedItems) {
                    ForEach(filteredDocuments) { item in
                        HStack {
                            Image(systemName: item.systemImage)
                                .foregroundColor(.accentColor)
                                .frame(width: 24)
                            VStack(alignment: .leading) {
                                Text(item.name)
                                    .font(.body)
                                Text(item.subtitle)
                                    .font(.caption)
                                    .foregroundColor(.secondary)
                            }
                            Spacer()
                        }
                        .tag(item.id)
                        .contentShape(Rectangle())
                        .onTapGesture {
                            if selectedItems.contains(item.id) {
                                selectedItems.remove(item.id)
                            } else {
                                selectedItems.insert(item.id)
                            }
                        }
                        .contextMenu {
                            Button {
                                shareItem = ShareItem(url: item.url)
                            } label: {
                                Label("Teilen", systemImage: "square.and.arrow.up")
                            }
                            Button("Entfernen", role: .destructive) {
                                documents.removeAll { $0.id == item.id }
                                selectedItems.remove(item.id)
                            }
                        }
                    }
                }
                .listStyle(.plain)
            }
            
            if let errorMessage {
                Text(errorMessage)
                    .font(.caption)
                    .foregroundColor(.red)
                    .padding(8)
            }
        }
        .fileImporter(
            isPresented: $showImporter,
            allowedContentTypes: [.item],
            allowsMultipleSelection: true
        ) { result in
            switch result {
            case .success(let urls):
                for url in urls {
                    let didStart = url.startAccessingSecurityScopedResource()
                    // Keep access for the lifetime of this session by storing the URL;
                    // stopAccessing is called when item is removed if needed.
                    let size = (try? FileManager.default.attributesOfItem(atPath: url.path)[.size] as? Int64) ?? 0
                    let modified = (try? FileManager.default.attributesOfItem(atPath: url.path)[.modificationDate] as? Date) ?? Date()
                    let item = FileItem(
                        name: url.lastPathComponent,
                        url: url,
                        isDirectory: url.hasDirectoryPath,
                        size: size,
                        modified: modified,
                        securityScoped: didStart
                    )
                    documents.append(item)
                }
            case .failure(let error):
                errorMessage = error.localizedDescription
            }
        }
        .sheet(item: $shareItem) { item in
            ActivityViewController(activityItems: [item.url])
        }
    }
    
    private var filteredDocuments: [FileItem] {
        var list = documents
        if !searchText.isEmpty {
            list = list.filter { $0.name.localizedCaseInsensitiveContains(searchText) }
        }
        if sortByName {
            list.sort { $0.name.localizedCaseInsensitiveCompare($1.name) == .orderedAscending }
        } else {
            list.sort { $0.modified > $1.modified }
        }
        return list
    }
    
    private func shareSelected() {
        if let first = documents.first(where: { selectedItems.contains($0.id) }) {
            shareItem = ShareItem(url: first.url)
        }
    }
}

struct FileItem: Identifiable {
    let id = UUID()
    let name: String
    let url: URL
    let isDirectory: Bool
    let size: Int64
    let modified: Date
    var securityScoped: Bool = false
    
    var systemImage: String {
        if isDirectory { return "folder.fill" }
        let ext = (name as NSString).pathExtension.lowercased()
        switch ext {
        case "pdf": return "doc.richtext"
        case "png", "jpg", "jpeg", "heic": return "photo"
        case "mp4", "mov": return "film"
        case "mp3", "m4a", "wav": return "music.note"
        case "txt", "md": return "doc.text"
        default: return "doc"
        }
    }
    
    var subtitle: String {
        let formatter = ByteCountFormatter()
        formatter.countStyle = .file
        let sizeStr = formatter.string(fromByteCount: size)
        let dateStr = modified.formatted(date: .abbreviated, time: .shortened)
        return "\(sizeStr) · \(dateStr)"
    }
}

struct ShareItem: Identifiable {
    let id = UUID()
    let url: URL
}

struct ActivityViewController: UIViewControllerRepresentable {
    let activityItems: [Any]
    
    func makeUIViewController(context: Context) -> UIActivityViewController {
        UIActivityViewController(activityItems: activityItems, applicationActivities: nil)
    }
    
    func updateUIViewController(_ uiViewController: UIActivityViewController, context: Context) {}
}
