import SwiftUI

struct DownloadsView: View {
    @EnvironmentObject var settings: SettingsStore
    
    var body: some View {
        VStack(spacing: 0) {
            HStack {
                Text("Downloads")
                    .font(.headline)
                Spacer()
                if !settings.downloads.isEmpty {
                    Button("Alle löschen", role: .destructive) {
                        settings.downloads.removeAll()
                    }
                    .font(.caption)
                }
            }
            .padding()
            
            Divider()
            
            if settings.downloads.isEmpty {
                VStack(spacing: 12) {
                    Image(systemName: "arrow.down.circle")
                        .font(.system(size: 40))
                        .foregroundColor(.secondary)
                    Text("Keine Downloads")
                        .font(.headline)
                    Text("Downloads aus dem Browser erscheinen hier, sobald die Download-API von WKWebView genutzt wird. Der aktuelle Implementierungsstand speichert Metadaten lokal; tatsächliche Datei-Downloads erfordern zusätzliche Delegate-Logik und Benutzer-Freigabe.")
                        .font(.caption)
                        .foregroundColor(.secondary)
                        .multilineTextAlignment(.center)
                        .padding(.horizontal, 30)
                }
                .frame(maxWidth: .infinity, maxHeight: .infinity)
            } else {
                List {
                    ForEach(settings.downloads) { item in
                        HStack {
                            Image(systemName: icon(for: item))
                            VStack(alignment: .leading) {
                                Text(item.filename)
                                    .font(.body)
                                Text(statusText(item))
                                    .font(.caption)
                                    .foregroundColor(.secondary)
                            }
                            Spacer()
                            if item.state == .downloading {
                                ProgressView(value: item.progress)
                                    .frame(width: 60)
                            }
                        }
                        .contextMenu {
                            if item.state == .completed, let url = item.localURL {
                                Button("Im Dateimanager zeigen") { }
                            }
                            Button("Entfernen", role: .destructive) {
                                settings.removeDownload(item.id)
                            }
                        }
                    }
                }
                .listStyle(.plain)
            }
        }
    }
    
    private func icon(for item: DownloadItem) -> String {
        switch item.state {
        case .completed: return "checkmark.circle.fill"
        case .failed: return "xmark.circle.fill"
        case .cancelled: return "slash.circle"
        default: return "arrow.down.circle"
        }
    }
    
    private func statusText(_ item: DownloadItem) -> String {
        switch item.state {
        case .pending: return "Wartend"
        case .downloading: return "Lädt… \(Int(item.progress * 100)) %"
        case .completed: return "Fertig"
        case .failed: return "Fehlgeschlagen"
        case .cancelled: return "Abgebrochen"
        }
    }
}