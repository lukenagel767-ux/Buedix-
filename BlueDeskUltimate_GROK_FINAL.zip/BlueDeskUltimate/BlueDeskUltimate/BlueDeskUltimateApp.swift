import SwiftUI
import GameController

@main
struct BlueDeskUltimateApp: App {
    @StateObject private var windowManager = WindowManager()
    @StateObject private var settingsStore = SettingsStore.shared
    @StateObject private var inputService = InputDeviceService.shared
    @StateObject private var pointerService = PointerService.shared
    
    var body: some Scene {
        WindowGroup {
            DesktopRootView()
                .environmentObject(windowManager)
                .environmentObject(settingsStore)
                .environmentObject(inputService)
                .environmentObject(pointerService)
                .preferredColorScheme(settingsStore.settings.isDarkMode ? .dark : .light)
                .onAppear {
                    inputService.refreshDeviceStatus()
                    inputService.updatePreferExternalInput(settingsStore.settings.preferExternalInput)
                    GCController.startWirelessControllerDiscovery {}
                }
        }
    }
}
