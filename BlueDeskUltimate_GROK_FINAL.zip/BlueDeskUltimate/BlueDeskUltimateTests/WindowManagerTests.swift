import XCTest
@testable import BlueDeskUltimate

/// Unit tests for WindowManager. These tests are written to run under XCTest on a Mac with Xcode.
/// They have NOT been executed in the Linux build environment.
@MainActor
final class WindowManagerTests: XCTestCase {
    
    var manager: WindowManager!
    
    override func setUp() async throws {
        manager = WindowManager()
        manager.clearAllWindows()
    }
    
    override func tearDown() async throws {
        manager.clearAllWindows()
        manager = nil
    }
    
    func testOpenWindowIncreasesCount() {
        let before = manager.windows.count
        _ = manager.openWindow(title: "Test", appType: .browser)
        XCTAssertEqual(manager.windows.count, before + 1)
    }
    
    func testFocusWindowSetsFocusedFlag() {
        let w1 = manager.openWindow(title: "A", appType: .notes)
        let w2 = manager.openWindow(title: "B", appType: .calculator)
        manager.focusWindow(w1.id)
        XCTAssertTrue(manager.windows.first(where: { $0.id == w1.id })?.isFocused == true)
        XCTAssertTrue(manager.windows.first(where: { $0.id == w2.id })?.isFocused == false)
        XCTAssertEqual(manager.focusedWindowID, w1.id)
    }
    
    func testMinimizeAndRestore() {
        let w = manager.openWindow(title: "Min", appType: .browser)
        manager.minimizeWindow(w.id)
        XCTAssertTrue(manager.windows.first(where: { $0.id == w.id })?.isMinimized == true)
        XCTAssertTrue(manager.visibleWindows.allSatisfy { $0.id != w.id })
        manager.restoreWindow(w.id)
        XCTAssertTrue(manager.windows.first(where: { $0.id == w.id })?.isMinimized == false)
    }
    
    func testCloseWindowRemovesIt() {
        let w = manager.openWindow(title: "Close", appType: .settings)
        manager.closeWindow(w.id)
        XCTAssertNil(manager.windows.first(where: { $0.id == w.id }))
    }
    
    func testSnapLeftHalf() {
        let w = manager.openWindow(title: "Snap", appType: .browser)
        manager.snapWindow(w.id, to: .leftHalf)
        let frame = manager.windows.first(where: { $0.id == w.id })?.frame
        XCTAssertNotNil(frame)
        XCTAssertEqual(frame?.origin.x, 0, accuracy: 1)
    }
    
    func testWorkspaceSwitch() {
        XCTAssertFalse(manager.workspaces.isEmpty)
        let target = manager.workspaces[1].id
        manager.switchWorkspace(to: target)
        XCTAssertEqual(manager.activeWorkspaceID, target)
    }
    
    func testMoveWindowToWorkspace() {
        let w = manager.openWindow(title: "Move", appType: .notes)
        let otherWS = manager.workspaces.first { $0.id != manager.activeWorkspaceID }!.id
        manager.moveWindow(w.id, toWorkspace: otherWS)
        XCTAssertEqual(manager.windows.first(where: { $0.id == w.id })?.workspaceID, otherWS)
    }
    
    func testMaximizeToggle() {
        let w = manager.openWindow(title: "Max", appType: .browser)
        manager.toggleMaximize(w.id)
        XCTAssertTrue(manager.windows.first(where: { $0.id == w.id })?.isMaximized == true)
        manager.toggleMaximize(w.id)
        XCTAssertTrue(manager.windows.first(where: { $0.id == w.id })?.isMaximized == false)
    }
}
