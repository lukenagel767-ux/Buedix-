import XCTest
@testable import BlueDeskUltimate

/// Tests for input prioritization logic.
/// NOT executed in the Linux environment – require Xcode.
@MainActor
final class InputDeviceServiceTests: XCTestCase {
    
    func testPreferExternalHidesTouchpadWhenMousePresent() {
        let service = InputDeviceService.shared
        service.updatePreferExternalInput(true)
        // We cannot simulate real GCMouse connection in unit tests without hardware.
        // Verify the published properties exist and default state is coherent.
        XCTAssertNotNil(service.shouldShowVirtualTouchpad)
        _ = service.statusDescription
    }
    
    func testStatusDescriptionNotEmpty() {
        let service = InputDeviceService.shared
        service.refreshDeviceStatus()
        XCTAssertFalse(service.statusDescription.isEmpty)
    }
}
