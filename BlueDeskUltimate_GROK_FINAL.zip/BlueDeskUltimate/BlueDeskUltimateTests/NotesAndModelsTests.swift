import XCTest
@testable import BlueDeskUltimate

@MainActor
final class NotesAndModelsTests: XCTestCase {
    
    func testNoteCreateUpdateDelete() {
        let store = SettingsStore.shared
        let before = store.notes.count
        let note = Note(title: "Testnotiz", content: "Inhalt")
        store.addNote(note)
        XCTAssertEqual(store.notes.count, before + 1)
        XCTAssertTrue(store.notes.contains { $0.id == note.id })
        
        var updated = note
        updated.title = "Geändert"
        store.updateNote(updated)
        XCTAssertEqual(store.notes.first { $0.id == note.id }?.title, "Geändert")
        
        store.deleteNote(note.id)
        XCTAssertFalse(store.notes.contains { $0.id == note.id })
    }
    
    func testBookmarkAddRemove() {
        let store = SettingsStore.shared
        let url = URL(string: "https://example.com")!
        let before = store.bookmarks.count
        store.addBookmark(title: "Example", url: url)
        XCTAssertEqual(store.bookmarks.count, before + 1)
        if let id = store.bookmarks.first?.id {
            store.removeBookmark(id)
            XCTAssertEqual(store.bookmarks.count, before)
        }
    }
    
    func testAppTypeDisplayNames() {
        for t in AppType.allCases {
            XCTAssertFalse(t.displayName.isEmpty)
            XCTAssertFalse(t.systemImage.isEmpty)
        }
    }
    
    func testDesktopWindowEquality() {
        let ws = UUID()
        let a = DesktopWindow(title: "A", appType: .browser, workspaceID: ws)
        let b = DesktopWindow(id: a.id, title: "A", appType: .browser, workspaceID: ws)
        XCTAssertEqual(a, b)
    }
}
